# DataInsight Hub

## Overview

DataInsight Hub is a Streamlit-based data analysis application that provides interactive visualizations and statistical analysis for CSV and Excel files. The application follows a modular architecture with separate utility classes for data processing, statistical calculations, and visualization generation using Plotly.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application uses a simple web-based architecture built on Streamlit with a modular utility system:

- **Frontend**: Streamlit web interface with sidebar controls and main content area
- **Backend Logic**: Python-based processing with utility modules
- **Data Processing**: Pandas for data manipulation and file handling
- **Visualization**: Plotly for interactive charts and graphs
- **Statistics**: SciPy for statistical calculations

## Key Components

### 1. Main Application (app.py)
- **Purpose**: Entry point and UI orchestration
- **Architecture Decision**: Single-page Streamlit app with session state management
- **Rationale**: Streamlit's session state provides simple data persistence across user interactions

### 2. Data Processor (utils/data_processor.py)
- **Purpose**: File loading and data preprocessing
- **Key Features**: 
  - Multi-format support (CSV, Excel)
  - Encoding fallback for CSV files
  - Column type categorization
- **Architecture Decision**: Separate class for data operations
- **Rationale**: Separation of concerns and reusability

### 3. Statistics Module (utils/statistics.py)
- **Purpose**: Statistical analysis and calculations
- **Key Features**:
  - Comprehensive numerical statistics
  - Correlation analysis
  - Strong correlation detection
- **Architecture Decision**: Dedicated statistics class with SciPy integration
- **Rationale**: Centralized statistical operations with scientific computing library

### 4. Visualizations Module (utils/visualizations.py)
- **Purpose**: Interactive chart generation
- **Key Features**:
  - Plotly-based interactive charts
  - Consistent color theming
  - Multiple chart types (histogram, box plot, etc.)
- **Architecture Decision**: Plotly over static matplotlib
- **Rationale**: Interactive visualizations enhance user experience and data exploration

## Data Flow

1. **File Upload**: User uploads CSV/Excel file through Streamlit sidebar
2. **Data Loading**: DataProcessor loads and validates file with encoding fallback
3. **Data Processing**: Columns are categorized by type (numerical, categorical, date)
4. **Session Storage**: Processed data stored in Streamlit session state
5. **Analysis**: Statistics and visualizations generated on-demand
6. **Display**: Results rendered in main Streamlit interface

## External Dependencies

### Core Libraries
- **Streamlit**: Web application framework
- **Pandas**: Data manipulation and analysis
- **NumPy**: Numerical computing
- **Plotly**: Interactive visualizations
- **SciPy**: Scientific computing and statistics

### File Format Support
- CSV files with UTF-8 and Latin-1 encoding support
- Excel files (.xlsx, .xls)

## Deployment Strategy

The application is designed for simple deployment:

- **Local Development**: Run via `streamlit run app.py`
- **Cloud Deployment**: Compatible with Streamlit Cloud, Heroku, or similar platforms
- **No Database**: Stateless design with session-based data storage
- **Dependencies**: Managed through requirements.txt (implied)

### Architecture Benefits
- **Simplicity**: No complex backend infrastructure required
- **Modularity**: Utility classes enable easy feature extension
- **Interactive**: Real-time data exploration capabilities
- **Portable**: Self-contained application with minimal dependencies

### Potential Limitations
- **Scalability**: Session state limits data size and concurrent users
- **Persistence**: Data not saved between sessions
- **Processing**: Limited to single-machine processing capabilities

## Recent Changes

### Critical Bug Fixes (January 27, 2025)
- **Array Ambiguity Error Fixed**: Resolved "Use a.any() or a.all()" error in resume analysis through proper exception handling
- **PyArrow Serialization Issues Resolved**: Created comprehensive data type conversion system to prevent Arrow table conversion failures
- **Statistics Module Compatibility**: Fixed numpy array handling in zscore calculations for outlier detection
- **Data Type Consistency**: Added fix_arrow_compatibility method to handle mixed numeric/string columns properly
- **All Limits Upgraded**: Significantly increased capacity limits throughout the application for better performance

### Previous Update (January 27, 2025)
- **AI Insights Feature**: Added comprehensive automated insight generation system
  - Natural language summaries using OpenAI GPT-4o for executive-level data understanding
  - Automated pattern detection including correlations, distributions, and anomalies
  - Data quality assessment with scoring and recommendations
  - Custom insight generation with interactive exploration options
  - Professional styling with priority-based recommendation system
- **Resume Analysis Feature**: Comprehensive AI-powered resume analysis system
  - PDF/DOCX resume upload and text extraction using PyMuPDF and python-docx
  - OpenAI GPT-4o integration for enhanced skill extraction and career recommendations
  - Company matching algorithm with intelligent scoring based on skills and experience
  - Skills gap analysis and personalized career guidance
  - Interactive results display with detailed insights and export options
- **Performance Improvements**: Fixed matplotlib styling issues and added caching for better performance
- **UI Enhancements**: Modern gradient design with professional styling throughout
- **Sample Data**: Added sample company dataset for demonstration purposes