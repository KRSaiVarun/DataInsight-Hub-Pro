import pandas as pd
import numpy as np
import streamlit as st
from typing import Dict, List, Any, Optional

class DataProcessor:
    """Handle data loading and preprocessing operations."""
    
    def load_file(self, uploaded_file) -> pd.DataFrame:
        """Load data from uploaded file."""
        try:
            file_extension = uploaded_file.name.split('.')[-1].lower()
            
            if file_extension == 'csv':
                # Try different encodings for CSV files
                try:
                    data = pd.read_csv(uploaded_file, encoding='utf-8')
                except UnicodeDecodeError:
                    uploaded_file.seek(0)  # Reset file pointer
                    data = pd.read_csv(uploaded_file, encoding='latin-1')
            
            elif file_extension in ['xlsx', 'xls']:
                data = pd.read_excel(uploaded_file)
            
            else:
                raise ValueError(f"Unsupported file format: {file_extension}")
            
            if data.empty:
                raise ValueError("The uploaded file is empty.")
            
            return data
            
        except Exception as e:
            raise Exception(f"Error loading file: {str(e)}")
    
    def process_data(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Process data and categorize columns by type."""
        processed_info = {
            'numerical_columns': [],
            'categorical_columns': [],
            'date_columns': [],
            'data_types': {},
            'missing_values': {},
            'unique_values': {}
        }
        
        for column in data.columns:
            col_data = data[column]
            if not isinstance(col_data, pd.Series):
                continue
            
            # Store basic info
            processed_info['data_types'][column] = str(col_data.dtype)
            processed_info['missing_values'][column] = int(col_data.isnull().sum())
            processed_info['unique_values'][column] = int(col_data.nunique())
            
            # Categorize columns
            if self._is_date_column(col_data):
                processed_info['date_columns'].append(column)
            elif self._is_numerical_column(col_data):
                processed_info['numerical_columns'].append(column)
            else:
                processed_info['categorical_columns'].append(column)
        
        return processed_info
    
    def _is_numerical_column(self, series: pd.Series) -> bool:
        """Check if a column contains numerical data."""
        if pd.api.types.is_numeric_dtype(series):
            return True
        
        # Try to convert to numeric
        try:
            pd.to_numeric(series, errors='raise')
            return True
        except (ValueError, TypeError):
            return False
    
    def _is_date_column(self, series: pd.Series) -> bool:
        """Check if a column contains date data."""
        if pd.api.types.is_datetime64_any_dtype(series):
            return True
        
        # Try to parse as datetime
        try:
            if series.dtype == 'object':
                # Sample more values for better detection
                sample_size = min(500, len(series))
                sample = series.dropna().head(sample_size)
                
                if len(sample) == 0:
                    return False
                
                # Try to parse sample
                parsed = pd.to_datetime(sample, errors='coerce')
                valid_dates = parsed.notna().sum()
                
                # If more than 70% of sample values are valid dates
                return (valid_dates / len(sample)) > 0.7
        except:
            pass
        
        return False
    
    def clean_data(self, data: pd.DataFrame, options: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        """Clean data based on specified options."""
        if options is None:
            options = {}
        
        cleaned_data = data.copy()
        
        # Handle missing values
        if options.get('drop_missing_rows', False):
            cleaned_data = cleaned_data.dropna()
        
        if options.get('fill_missing_numerical', False):
            numerical_cols = cleaned_data.select_dtypes(include=[np.number]).columns
            cleaned_data[numerical_cols] = cleaned_data[numerical_cols].fillna(
                cleaned_data[numerical_cols].mean()
            )
        
        if options.get('fill_missing_categorical', False):
            categorical_cols = cleaned_data.select_dtypes(include=['object']).columns
            cleaned_data[categorical_cols] = cleaned_data[categorical_cols].fillna('Unknown')
        
        # Remove duplicates
        if options.get('remove_duplicates', False):
            cleaned_data = cleaned_data.drop_duplicates()
        
        return cleaned_data
    
    def fix_arrow_compatibility(self, data: pd.DataFrame) -> pd.DataFrame:
        """Fix data types for Arrow compatibility and prevent serialization errors."""
        cleaned_data = data.copy()
        
        for column in cleaned_data.columns:
            col_series = cleaned_data[column]
            
            # Handle object columns that cause Arrow conversion issues
            if col_series.dtype == 'object':
                # Check for mixed numeric/string values
                non_null_values = col_series.dropna()
                if len(non_null_values) == 0:
                    # Empty column, convert to string
                    cleaned_data[column] = col_series.astype(str)
                    continue
                
                # Convert all values to string first to check patterns
                str_values = col_series.astype(str)
                
                # Try to identify if values are primarily numeric
                numeric_pattern_count = 0
                for val in non_null_values.head(100):  # Sample first 100
                    str_val = str(val)
                    # Check if it looks like a number (including scientific notation)
                    try:
                        float(str_val)
                        numeric_pattern_count += 1
                    except (ValueError, TypeError):
                        pass
                
                # Decision logic for conversion
                if numeric_pattern_count == len(non_null_values.head(100)):
                    # All sampled values are numeric - convert to float64
                    try:
                        cleaned_data[column] = pd.to_numeric(col_series, errors='coerce').astype('float64')
                    except:
                        # If conversion fails, force to string
                        cleaned_data[column] = str_values.replace('nan', None)
                else:
                    # Mixed or text values - force consistent string type
                    cleaned_data[column] = str_values.replace('nan', None)
                    cleaned_data[column] = cleaned_data[column].replace('NaN', None)
                    cleaned_data[column] = cleaned_data[column].replace('<NA>', None)
            
            # Handle integer columns - convert to float to avoid NaN issues
            elif col_series.dtype in ['int64', 'int32', 'int16', 'int8']:
                cleaned_data[column] = col_series.astype('float64')
            
            # Handle boolean columns
            elif col_series.dtype == 'bool':
                cleaned_data[column] = col_series.astype(str)
        
        return cleaned_data
    
    def get_data_summary(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Get comprehensive data summary."""
        summary = {
            'shape': data.shape,
            'columns': list(data.columns),
            'dtypes': data.dtypes.to_dict(),
            'missing_values': data.isnull().sum().to_dict(),
            'unique_values': data.nunique().to_dict(),
            'memory_usage': data.memory_usage(deep=True).sum(),
        }
        
        # Add numerical summaries
        numerical_data = data.select_dtypes(include=[np.number])
        if not numerical_data.empty:
            summary['numerical_summary'] = numerical_data.describe().to_dict()
        
        return summary
