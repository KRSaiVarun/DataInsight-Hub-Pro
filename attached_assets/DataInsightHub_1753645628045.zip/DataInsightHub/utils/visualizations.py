import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from typing import Optional, List

class Visualizations:
    """Create interactive visualizations using Plotly."""
    
    def __init__(self):
        self.color_palette = px.colors.qualitative.Set3
        self.theme = {
            'background_color': 'white',
            'grid_color': 'lightgray',
            'text_color': 'black',
            'font_family': 'Arial, sans-serif'
        }
    
    def create_histogram(self, data: pd.DataFrame, column: str, bins: int = 30) -> go.Figure:
        """Create an interactive histogram."""
        fig = px.histogram(
            data, 
            x=column, 
            nbins=bins,
            title=f'Distribution of {column}',
            labels={'count': 'Frequency'},
            color_discrete_sequence=[self.color_palette[0]]
        )
        
        fig.update_layout(
            showlegend=False,
            hovermode='x unified',
            plot_bgcolor=self.theme['background_color'],
            paper_bgcolor=self.theme['background_color'],
            font=dict(family=self.theme['font_family'], color=self.theme['text_color']),
            xaxis=dict(gridcolor=self.theme['grid_color']),
            yaxis=dict(gridcolor=self.theme['grid_color'])
        )
        
        return fig
    
    def create_box_plot(self, data: pd.DataFrame, columns: List[str], max_columns: int = 20) -> go.Figure:
        """Create box plots for multiple columns."""
        fig = go.Figure()
        
        for i, column in enumerate(columns[:max_columns]):
            fig.add_trace(go.Box(
                y=data[column].dropna(),
                name=column,
                marker_color=self.color_palette[i % len(self.color_palette)]
            ))
        
        fig.update_layout(
            title="Box Plot Comparison",
            yaxis_title="Values",
            showlegend=True
        )
        
        return fig
    
    def create_scatter_plot(self, data: pd.DataFrame, x_col: str, y_col: str, 
                          color_col: Optional[str] = None) -> go.Figure:
        """Create an interactive scatter plot."""
        if color_col:
            fig = px.scatter(
                data, 
                x=x_col, 
                y=y_col, 
                color=color_col,
                title=f'{y_col} vs {x_col}',
                hover_data=[col for col in data.columns if col in [x_col, y_col, color_col]]
            )
        else:
            fig = px.scatter(
                data, 
                x=x_col, 
                y=y_col,
                title=f'{y_col} vs {x_col}',
                color_discrete_sequence=[self.color_palette[0]]
            )
        
        # Add trendline
        fig.add_trace(go.Scatter(
            x=data[x_col],
            y=np.poly1d(np.polyfit(data[x_col].dropna(), data[y_col].dropna(), 1))(data[x_col]),
            mode='lines',
            name='Trend Line',
            line=dict(dash='dash', color='red')
        ))
        
        return fig
    
    def create_line_chart(self, data: pd.DataFrame, date_col: Optional[str], 
                         value_col: str) -> go.Figure:
        """Create a line chart for time series data."""
        if date_col:
            # Convert date column to datetime
            plot_data = data.copy()
            plot_data[date_col] = pd.to_datetime(plot_data[date_col])
            plot_data = plot_data.sort_values(date_col)
            
            fig = px.line(
                plot_data, 
                x=date_col, 
                y=value_col,
                title=f'{value_col} over Time',
                color_discrete_sequence=[self.color_palette[0]]
            )
        else:
            # Use index as x-axis
            fig = px.line(
                data, 
                y=value_col,
                title=f'{value_col} Trend',
                color_discrete_sequence=[self.color_palette[0]]
            )
            fig.update_xaxes(title="Index")
        
        fig.update_layout(hovermode='x unified')
        return fig
    
    def create_correlation_heatmap(self, correlation_matrix: pd.DataFrame) -> go.Figure:
        """Create a correlation heatmap."""
        fig = go.Figure(data=go.Heatmap(
            z=correlation_matrix.values,
            x=correlation_matrix.columns,
            y=correlation_matrix.columns,
            colorscale='RdBu',
            zmid=0,
            text=np.round(correlation_matrix.values, 2),
            texttemplate="%{text}",
            textfont={"size": 10},
            hoverongaps=False
        ))
        
        fig.update_layout(
            title="Correlation Matrix",
            xaxis_title="Variables",
            yaxis_title="Variables"
        )
        
        return fig
    
    def create_distribution_comparison(self, data: pd.DataFrame, columns: List[str]) -> go.Figure:
        """Create overlapping distribution plots."""
        fig = go.Figure()
        
        for i, column in enumerate(columns):
            fig.add_trace(go.Histogram(
                x=data[column].dropna(),
                name=column,
                opacity=0.7,
                marker_color=self.color_palette[i % len(self.color_palette)],
                histnorm='probability density'
            ))
        
        fig.update_layout(
            title="Distribution Comparison",
            xaxis_title="Values",
            yaxis_title="Density",
            barmode='overlay'
        )
        
        return fig
    
    def create_trend_analysis(self, data: pd.DataFrame, date_col: Optional[str], 
                            value_col: str, time_period: str = "Daily") -> go.Figure:
        """Create trend analysis visualization."""
        plot_data = data.copy()
        
        if date_col:
            plot_data[date_col] = pd.to_datetime(plot_data[date_col])
            plot_data = plot_data.sort_values(date_col)
            
            # Aggregate by time period
            if time_period == "Weekly":
                plot_data['period'] = plot_data[date_col].dt.to_period('W')
            elif time_period == "Monthly":
                plot_data['period'] = plot_data[date_col].dt.to_period('M')
            elif time_period == "Quarterly":
                plot_data['period'] = plot_data[date_col].dt.to_period('Q')
            elif time_period == "Yearly":
                plot_data['period'] = plot_data[date_col].dt.to_period('Y')
            else:  # Daily
                plot_data['period'] = plot_data[date_col].dt.date
            
            # Group by period and calculate mean
            if time_period != "Daily":
                aggregated = plot_data.groupby('period')[value_col].agg(['mean', 'std']).reset_index()
                aggregated['period'] = aggregated['period'].astype(str)
                x_values = aggregated['period'].tolist()
                y_values = aggregated['mean'].tolist()
                error_y = aggregated['std'].tolist()
            else:
                x_values = plot_data[date_col].tolist()
                y_values = plot_data[value_col].tolist()
                error_y = None
        else:
            x_values = list(range(len(plot_data)))
            y_values = plot_data[value_col].tolist()
            error_y = None
        
        # Create main line plot
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=x_values,
            y=y_values,
            mode='lines+markers',
            name=value_col,
            error_y=dict(array=error_y) if error_y is not None else None,
            line=dict(color=self.color_palette[0])
        ))
        
        # Add trend line
        if len(y_values) > 1:
            x_numeric = np.arange(len(y_values))
            try:
                z = np.polyfit(x_numeric, y_values, 1)
                trend_line = np.poly1d(z)(x_numeric).tolist()
            except (np.linalg.LinAlgError, ValueError):
                trend_line = [np.mean(y_values)] * len(y_values)
            
            fig.add_trace(go.Scatter(
                x=x_values,
                y=trend_line,
                mode='lines',
                name='Trend Line',
                line=dict(dash='dash', color='red')
            ))
        
        fig.update_layout(
            title=f'{value_col} Trend Analysis ({time_period})',
            xaxis_title='Time' if date_col else 'Index',
            yaxis_title=value_col,
            hovermode='x unified'
        )
        
        return fig
