import pandas as pd
import numpy as np
import re
import fitz  # PyMuPDF
from docx import Document
import PyPDF2
from typing import Dict, List, Any, Tuple
import streamlit as st
import os
import json
from openai import OpenAI

class ResumeAnalyzer:
    """Extract and analyze resume content to match with companies."""
    
    def __init__(self):
        # Initialize OpenAI client
        self.openai_client = None
        try:
            api_key = os.environ.get("OPENAI_API_KEY")
            if api_key:
                self.openai_client = OpenAI(api_key=api_key)
        except Exception:
            pass  # Fall back to traditional analysis
        
        # Common technical skills categorized
        self.skill_categories = {
            'programming': [
                'python', 'java', 'javascript', 'c++', 'c#', 'php', 'ruby', 'go', 'rust',
                'swift', 'kotlin', 'typescript', 'scala', 'r', 'matlab', 'sql', 'html',
                'css', 'react', 'angular', 'vue', 'node.js', 'express', 'django', 'flask',
                'spring', 'laravel', 'asp.net', 'jquery', 'bootstrap'
            ],
            'data_science': [
                'machine learning', 'deep learning', 'neural networks', 'tensorflow',
                'pytorch', 'scikit-learn', 'pandas', 'numpy', 'matplotlib', 'seaborn',
                'plotly', 'tableau', 'power bi', 'data analysis', 'data visualization',
                'statistics', 'nlp', 'computer vision', 'ai', 'artificial intelligence'
            ],
            'cloud_devops': [
                'aws', 'azure', 'gcp', 'google cloud', 'docker', 'kubernetes', 'jenkins',
                'terraform', 'ansible', 'chef', 'puppet', 'gitlab', 'github actions',
                'circleci', 'travis ci', 'nginx', 'apache', 'linux', 'bash', 'shell scripting'
            ],
            'databases': [
                'mysql', 'postgresql', 'mongodb', 'redis', 'elasticsearch', 'cassandra',
                'oracle', 'sql server', 'sqlite', 'dynamodb', 'neo4j', 'firebase'
            ],
            'business': [
                'project management', 'agile', 'scrum', 'kanban', 'business analysis',
                'product management', 'marketing', 'sales', 'finance', 'accounting',
                'operations', 'strategy', 'consulting', 'leadership', 'communication'
            ]
        }
        
        # Experience level indicators
        self.experience_indicators = {
            'entry': ['intern', 'graduate', 'junior', 'associate', 'trainee', 'entry level'],
            'mid': ['senior', 'lead', 'specialist', 'analyst', 'consultant', 'coordinator'],
            'senior': ['manager', 'director', 'head', 'principal', 'architect', 'vp', 'vice president', 'cto', 'ceo']
        }
        
        # Education indicators
        self.education_keywords = [
            'bachelor', 'master', 'phd', 'doctorate', 'degree', 'university', 'college',
            'bs', 'ba', 'ms', 'ma', 'mba', 'computer science', 'engineering', 'business',
            'mathematics', 'statistics', 'data science', 'information technology'
        ]
    
    def extract_text_from_pdf(self, file) -> str:
        """Extract text from PDF file using PyMuPDF."""
        try:
            # Reset file pointer
            file.seek(0)
            pdf_content = file.read()
            
            # Use PyMuPDF for better text extraction
            pdf_document = fitz.open(stream=pdf_content, filetype="pdf")
            text = ""
            
            for page_num in range(pdf_document.page_count):
                page = pdf_document[page_num]
                text += page.get_text()
            
            pdf_document.close()
            return text
            
        except Exception as e:
            # Fallback to PyPDF2
            try:
                file.seek(0)
                reader = PyPDF2.PdfReader(file)
                text = ""
                for page in reader.pages:
                    text += page.extract_text()
                return text
            except:
                raise Exception(f"Could not extract text from PDF: {str(e)}")
    
    def extract_text_from_docx(self, file) -> str:
        """Extract text from DOCX file."""
        try:
            file.seek(0)
            doc = Document(file)
            text = ""
            
            # Extract text from paragraphs
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            
            # Extract text from tables
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        text += cell.text + " "
                    text += "\n"
            
            return text
            
        except Exception as e:
            raise Exception(f"Could not extract text from DOCX: {str(e)}")
    
    def extract_resume_text(self, uploaded_file) -> str:
        """Extract text from uploaded resume file."""
        file_extension = uploaded_file.name.split('.')[-1].lower()
        
        if file_extension == 'pdf':
            return self.extract_text_from_pdf(uploaded_file)
        elif file_extension in ['docx', 'doc']:
            return self.extract_text_from_docx(uploaded_file)
        else:
            raise ValueError(f"Unsupported file format: {file_extension}")
    
    def extract_skills_with_ai(self, text: str) -> Dict[str, List[str]]:
        """Extract skills using OpenAI for enhanced accuracy."""
        if not self.openai_client:
            return self.extract_skills_traditional(text)
        
        try:
            prompt = f"""
            Analyze this resume text and extract all technical and professional skills.
            Categorize them into these groups: programming, data_science, cloud_devops, databases, business.
            
            Resume text:
            {text[:3000]}  # Limit text to avoid token limits
            
            Return only valid JSON in this format:
            {{
                "programming": ["skill1", "skill2"],
                "data_science": ["skill1", "skill2"],
                "cloud_devops": ["skill1", "skill2"],
                "databases": ["skill1", "skill2"],
                "business": ["skill1", "skill2"]
            }}
            """
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
                messages=[
                    {"role": "system", "content": "You are an expert resume analyzer. Extract skills accurately and categorize them properly. Return only valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                max_tokens=1000
            )
            
            content = response.choices[0].message.content
            if content:
                ai_skills = json.loads(content)
            else:
                return self.extract_skills_traditional(text)
            
            # Combine with traditional extraction for completeness
            traditional_skills = self.extract_skills_traditional(text)
            
            # Merge results
            combined_skills = {}
            for category in self.skill_categories.keys():
                ai_list = ai_skills.get(category, [])
                trad_list = traditional_skills.get(category, [])
                
                # Combine and deduplicate
                all_skills = list(set([skill.lower() for skill in ai_list + trad_list]))
                if all_skills:
                    combined_skills[category] = all_skills
            
            return combined_skills
            
        except Exception as e:
            # Fall back to traditional extraction
            return self.extract_skills_traditional(text)
    
    def extract_skills_traditional(self, text: str) -> Dict[str, List[str]]:
        """Traditional skill extraction method."""
        text_lower = text.lower()
        extracted_skills = {}
        
        for category, skills in self.skill_categories.items():
            found_skills = []
            for skill in skills:
                # Use word boundaries to avoid partial matches
                pattern = r'\b' + re.escape(skill.lower()) + r'\b'
                if re.search(pattern, text_lower):
                    found_skills.append(skill)
            
            if found_skills:
                extracted_skills[category] = found_skills
        
        return extracted_skills
    
    def extract_skills(self, text: str) -> Dict[str, List[str]]:
        """Extract skills using AI if available, otherwise traditional method."""
        return self.extract_skills_with_ai(text)
    
    def extract_experience_level(self, text: str) -> str:
        """Determine experience level from resume text."""
        text_lower = text.lower()
        
        # Count years of experience
        years_pattern = r'(\d+)\s*(?:years?|yrs?)\s*(?:of\s*)?(?:experience|exp)'
        years_matches = re.findall(years_pattern, text_lower)
        
        if years_matches:
            max_years = max([int(year) for year in years_matches])
            if max_years >= 8:
                return 'senior'
            elif max_years >= 3:
                return 'mid'
            else:
                return 'entry'
        
        # Check for experience indicators
        senior_count = sum(1 for indicator in self.experience_indicators['senior'] 
                          if indicator in text_lower)
        mid_count = sum(1 for indicator in self.experience_indicators['mid'] 
                       if indicator in text_lower)
        entry_count = sum(1 for indicator in self.experience_indicators['entry'] 
                         if indicator in text_lower)
        
        if senior_count >= 2 or senior_count > mid_count:
            return 'senior'
        elif mid_count >= 2 or mid_count > entry_count:
            return 'mid'
        else:
            return 'entry'
    
    def extract_education(self, text: str) -> List[str]:
        """Extract education information from resume text."""
        text_lower = text.lower()
        education = []
        
        for keyword in self.education_keywords:
            if keyword in text_lower:
                education.append(keyword)
        
        return list(set(education))  # Remove duplicates
    
    def extract_contact_info(self, text: str) -> Dict[str, str]:
        """Extract contact information from resume text."""
        contact_info = {}
        
        # Email pattern
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        email_match = re.search(email_pattern, text)
        if email_match:
            contact_info['email'] = email_match.group()
        
        # Phone pattern
        phone_pattern = r'(?:\+?1[-.\s]?)?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})'
        phone_match = re.search(phone_pattern, text)
        if phone_match:
            contact_info['phone'] = phone_match.group()
        
        # LinkedIn pattern
        linkedin_pattern = r'linkedin\.com/in/([a-zA-Z0-9-]+)'
        linkedin_match = re.search(linkedin_pattern, text)
        if linkedin_match:
            contact_info['linkedin'] = linkedin_match.group()
        
        return contact_info
    
    def analyze_resume(self, uploaded_file) -> Dict[str, Any]:
        """Comprehensive resume analysis."""
        try:
            # Extract text
            text = self.extract_resume_text(uploaded_file)
            
            if not text.strip():
                raise ValueError("No text could be extracted from the resume")
            
            # Perform analysis
            analysis = {
                'text': text,
                'skills': self.extract_skills(text),
                'experience_level': self.extract_experience_level(text),
                'education': self.extract_education(text),
                'contact_info': self.extract_contact_info(text),
                'text_length': len(text),
                'word_count': len(text.split())
            }
            
            return analysis
            
        except Exception as e:
            raise Exception(f"Error analyzing resume: {str(e)}")
    
    def match_with_companies(self, resume_analysis: Dict[str, Any], 
                           companies_data: pd.DataFrame) -> pd.DataFrame:
        """Match resume with companies based on skills and requirements."""
        if companies_data.empty:
            return pd.DataFrame()
        
        resume_skills = resume_analysis.get('skills', {})
        all_resume_skills = []
        for category, skills in resume_skills.items():
            all_resume_skills.extend([skill.lower() for skill in skills])
        
        experience_level = resume_analysis.get('experience_level', 'entry')
        
        matches = []
        
        for idx, company in companies_data.iterrows():
            match_score = 0
            matched_skills = []
            
            # Check each column for skill matches
            for column in companies_data.columns:
                col_value = company[column]
                # Handle scalar values and prevent array ambiguity completely
                if col_value is None:
                    continue
                
                # Convert to string first to avoid array ambiguity issues
                str_value = str(col_value)
                if str_value.lower() in ['nan', 'none', '']:
                    continue
                
                column_text = str(col_value).lower()
                
                # Count skill matches
                for skill in all_resume_skills:
                    if skill in column_text:
                        match_score += 1
                        if skill not in matched_skills:
                            matched_skills.append(skill)
            
            # Bonus for experience level match - safely handle company values
            company_values = []
            for val in company.values:
                if val is not None:
                    str_val = str(val)
                    if str_val.lower() not in ['nan', 'none', '']:
                        company_values.append(str_val)
            company_text = ' '.join(company_values).lower()
            
            if experience_level == 'senior' and any(term in company_text for term in ['senior', 'lead', 'manager', 'director']):
                match_score += 5
            elif experience_level == 'mid' and any(term in company_text for term in ['mid', 'intermediate', 'experienced']):
                match_score += 3
            elif experience_level == 'entry' and any(term in company_text for term in ['junior', 'entry', 'graduate', 'intern']):
                match_score += 3
            
            if match_score > 0:
                match_info = {}
                
                # Copy company data, ensuring all values are proper Python types
                for key, value in company.items():
                    if value is None:
                        match_info[key] = None
                    else:
                        str_val = str(value)
                        if str_val.lower() in ['nan', 'none', '']:
                            match_info[key] = None
                        elif hasattr(value, 'item'):  # Handle numpy types
                            match_info[key] = value.item()
                        else:
                            match_info[key] = str_val
                
                match_info['match_score'] = int(match_score)  # Convert to int to avoid numpy.bool issues
                match_info['matched_skills'] = matched_skills
                match_info['skill_match_percentage'] = round((len(matched_skills) / max(len(all_resume_skills), 1)) * 100, 1)
                matches.append(match_info)
        
        # Convert to DataFrame and sort by match score
        if matches:
            matches_df = pd.DataFrame(matches)
            matches_df = matches_df.sort_values('match_score', ascending=False)
            return matches_df
        else:
            return pd.DataFrame()
    
    def generate_ai_recommendations(self, resume_analysis: Dict[str, Any], 
                                  top_matches: pd.DataFrame) -> Dict[str, Any]:
        """Generate AI-powered recommendations."""
        if not self.openai_client:
            return self.generate_traditional_recommendations(resume_analysis, top_matches)
        
        try:
            # Prepare context for AI
            skills_summary = {}
            for category, skills in resume_analysis.get('skills', {}).items():
                skills_summary[category] = len(skills)
            
            experience_level = resume_analysis.get('experience_level', 'entry')
            
            matches_summary = ""
            if not top_matches.empty:
                matches_summary = f"Found {len(top_matches)} company matches with average score {top_matches['match_score'].mean():.1f}"
            
            prompt = f"""
            Analyze this resume profile and provide career recommendations:
            
            Skills by category: {skills_summary}
            Experience level: {experience_level}
            Company matches: {matches_summary}
            
            Provide recommendations in JSON format:
            {{
                "skill_gaps": ["skill1", "skill2"],
                "experience_advice": "specific advice text",
                "improvement_areas": ["area1", "area2"],
                "career_next_steps": ["step1", "step2"]
            }}
            """
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
                messages=[
                    {"role": "system", "content": "You are a career counselor providing personalized recommendations based on resume analysis."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                max_tokens=1200
            )
            
            content = response.choices[0].message.content
            if content:
                ai_recommendations = json.loads(content)
            else:
                return self.generate_traditional_recommendations(resume_analysis, top_matches)
            
            # Combine with traditional recommendations
            traditional_recs = self.generate_traditional_recommendations(resume_analysis, top_matches)
            
            # Merge results
            combined_recommendations = {
                'skill_gaps': ai_recommendations.get('skill_gaps', []) + traditional_recs.get('skill_gaps', [])[:5],
                'experience_advice': ai_recommendations.get('experience_advice', traditional_recs.get('experience_advice', '')),
                'improvement_areas': ai_recommendations.get('improvement_areas', traditional_recs.get('improvement_areas', [])),
                'career_next_steps': ai_recommendations.get('career_next_steps', []),
                'top_companies': traditional_recs.get('top_companies', [])
            }
            
            return combined_recommendations
            
        except Exception as e:
            return self.generate_traditional_recommendations(resume_analysis, top_matches)
    
    def generate_traditional_recommendations(self, resume_analysis: Dict[str, Any], 
                                           top_matches: pd.DataFrame) -> Dict[str, Any]:
        """Generate traditional recommendations."""
        recommendations = {
            'skill_gaps': [],
            'experience_advice': '',
            'education_suggestions': [],
            'top_companies': [],
            'improvement_areas': []
        }
        
        resume_skills = resume_analysis.get('skills', {})
        experience_level = resume_analysis.get('experience_level', 'entry')
        
        # Analyze skill gaps
        all_skills = set()
        for category, skills in self.skill_categories.items():
            all_skills.update(skills)
        
        resume_skill_list = []
        for category, skills in resume_skills.items():
            resume_skill_list.extend([skill.lower() for skill in skills])
        
        # Find common skills in top matches that candidate doesn't have
        if not top_matches.empty:
            common_skills_in_matches = set()
            for _, match in top_matches.head(10).iterrows():
                match_text = ' '.join([str(val) for val in match.values if pd.notna(val)]).lower()
                for skill in all_skills:
                    if skill in match_text and skill not in resume_skill_list:
                        common_skills_in_matches.add(skill)
            
            recommendations['skill_gaps'] = list(common_skills_in_matches)[:10]
        
        # Experience advice
        if experience_level == 'entry':
            recommendations['experience_advice'] = "Focus on building foundational skills and gaining practical experience through projects or internships."
        elif experience_level == 'mid':
            recommendations['experience_advice'] = "Consider developing leadership skills and specializing in specific domains to advance to senior roles."
        else:
            recommendations['experience_advice'] = "Look for strategic roles that leverage your extensive experience and consider mentoring opportunities."
        
        # Top companies
        if not top_matches.empty:
            recommendations['top_companies'] = top_matches.head(5).to_dict('records')
        
        # Improvement areas
        skill_count = sum(len(skills) for skills in resume_skills.values())
        if skill_count < 10:
            recommendations['improvement_areas'].append("Consider adding more technical skills to your resume")
        
        if 'contact_info' not in resume_analysis or not resume_analysis['contact_info']:
            recommendations['improvement_areas'].append("Ensure your contact information is clearly visible")
        
        if resume_analysis.get('word_count', 0) < 200:
            recommendations['improvement_areas'].append("Consider expanding your resume with more detailed descriptions")
        
        return recommendations
    
    def generate_recommendations(self, resume_analysis: Dict[str, Any], 
                               top_matches: pd.DataFrame) -> Dict[str, Any]:
        """Generate recommendations using AI if available."""
        return self.generate_ai_recommendations(resume_analysis, top_matches)