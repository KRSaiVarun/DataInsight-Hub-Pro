import pandas as pd
import numpy as np
from scipy import stats
from typing import Dict, List, Any
import warnings
warnings.filterwarnings('ignore')

class Statistics:
    """Calculate comprehensive statistical measures."""
    
    def calculate_numerical_stats(self, data: pd.DataFrame) -> pd.DataFrame:
        """Calculate comprehensive statistics for numerical columns."""
        stats_dict = {}
        
        for column in data.columns:
            col_data = data[column].dropna()
            
            if len(col_data) == 0:
                continue
            
            stats_dict[column] = {
                'Count': len(col_data),
                'Mean': col_data.mean(),
                'Median': col_data.median(),
                'Mode': col_data.mode().iloc[0] if not col_data.mode().empty else np.nan,
                'Std Dev': col_data.std(),
                'Variance': col_data.var(),
                'Min': col_data.min(),
                'Max': col_data.max(),
                'Range': col_data.max() - col_data.min(),
                'Q1 (25%)': col_data.quantile(0.25),
                'Q3 (75%)': col_data.quantile(0.75),
                'IQR': col_data.quantile(0.75) - col_data.quantile(0.25),
                'Skewness': stats.skew(col_data),
                'Kurtosis': stats.kurtosis(col_data),
                'Missing Values': data[column].isnull().sum(),
                'Unique Values': col_data.nunique()
            }
        
        return pd.DataFrame(stats_dict).T.round(4)
    
    def calculate_correlation_matrix(self, data: pd.DataFrame) -> pd.DataFrame:
        """Calculate correlation matrix for numerical data."""
        return data.corr().round(4)
    
    def find_strong_correlations(self, correlation_matrix: pd.DataFrame, 
                               threshold: float = 0.7) -> pd.DataFrame:
        """Find pairs of variables with strong correlations."""
        strong_corr = []
        
        for i in range(len(correlation_matrix.columns)):
            for j in range(i + 1, len(correlation_matrix.columns)):
                corr_value = correlation_matrix.iloc[i, j]
                
                if abs(corr_value) >= threshold:
                    strong_corr.append({
                        'Variable 1': correlation_matrix.columns[i],
                        'Variable 2': correlation_matrix.columns[j],
                        'Correlation': corr_value,
                        'Strength': self._get_correlation_strength(corr_value),
                        'Direction': 'Positive' if corr_value > 0 else 'Negative'
                    })
        
        return pd.DataFrame(strong_corr).sort_values('Correlation', key=abs, ascending=False)
    
    def _get_correlation_strength(self, correlation: float) -> str:
        """Determine correlation strength based on value."""
        abs_corr = abs(correlation)
        
        if abs_corr >= 0.9:
            return 'Very Strong'
        elif abs_corr >= 0.7:
            return 'Strong'
        elif abs_corr >= 0.5:
            return 'Moderate'
        elif abs_corr >= 0.3:
            return 'Weak'
        else:
            return 'Very Weak'
    
    def calculate_trend_stats(self, values: np.ndarray) -> Dict[str, Any]:
        """Calculate trend statistics for time series data."""
        if len(values) < 2:
            return {
                'trend_direction': 'Insufficient Data',
                'slope': 0,
                'r_squared': 0,
                'volatility': 0
            }
        
        # Remove NaN values
        clean_values = values[~np.isnan(values)]
        x = np.arange(len(clean_values))
        
        if len(clean_values) < 2:
            return {
                'trend_direction': 'Insufficient Data',
                'slope': 0,
                'r_squared': 0,
                'volatility': 0
            }
        
        # Linear regression
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, clean_values)
        
        # Determine trend direction
        if abs(slope) < 0.001:
            trend_direction = 'Stable'
        elif slope > 0:
            trend_direction = 'Increasing'
        else:
            trend_direction = 'Decreasing'
        
        # Calculate volatility (coefficient of variation)
        volatility = np.std(clean_values) / np.mean(clean_values) if np.mean(clean_values) != 0 else 0
        
        return {
            'trend_direction': trend_direction,
            'slope': slope,
            'r_squared': r_value ** 2,
            'p_value': p_value,
            'volatility': abs(volatility)
        }
    
    def detect_outliers(self, data: pd.Series, method: str = 'iqr') -> Dict[str, Any]:
        """Detect outliers using specified method."""
        clean_data = data.dropna()
        
        if method == 'iqr':
            Q1 = clean_data.quantile(0.25)
            Q3 = clean_data.quantile(0.75)
            IQR = Q3 - Q1
            
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            outliers = clean_data[(clean_data < lower_bound) | (clean_data > upper_bound)]
            
        elif method == 'zscore':
            try:
                # Convert to numpy array and ensure proper handling
                if hasattr(clean_data, 'values'):
                    data_values = clean_data.values
                else:
                    data_values = np.array(clean_data)
                z_scores = np.abs(stats.zscore(data_values))
                outliers = clean_data[z_scores > 3]
                lower_bound = float(clean_data.mean() - 3 * clean_data.std())
                upper_bound = float(clean_data.mean() + 3 * clean_data.std())
            except Exception:
                # Fallback to IQR method if zscore fails
                Q1 = clean_data.quantile(0.25)
                Q3 = clean_data.quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                outliers = clean_data[(clean_data < lower_bound) | (clean_data > upper_bound)]
        else:
            # Default to IQR method
            Q1 = clean_data.quantile(0.25)
            Q3 = clean_data.quantile(0.75)
            IQR = Q3 - Q1
            
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            outliers = clean_data[(clean_data < lower_bound) | (clean_data > upper_bound)]
        
        return {
            'outliers': outliers,
            'outlier_count': len(outliers),
            'outlier_percentage': (len(outliers) / len(clean_data)) * 100,
            'lower_bound': lower_bound,
            'upper_bound': upper_bound
        }
    
    def calculate_distribution_stats(self, data: pd.Series) -> Dict[str, Any]:
        """Calculate distribution-related statistics."""
        clean_data = data.dropna()
        
        if len(clean_data) == 0:
            return {}
        
        # Normality test (Shapiro-Wilk for small samples, Anderson-Darling for larger)
        if len(clean_data) <= 10000:
            shapiro_stat, shapiro_p = stats.shapiro(clean_data)
            normality_test = {
                'test': 'Shapiro-Wilk',
                'statistic': shapiro_stat,
                'p_value': shapiro_p,
                'is_normal': shapiro_p > 0.05
            }
        else:
            # Use Anderson-Darling test for larger samples
            anderson_stat, critical_values, significance_levels = stats.anderson(clean_data)
            normality_test = {
                'test': 'Anderson-Darling',
                'statistic': anderson_stat,
                'critical_value_5%': critical_values[2],  # 5% significance level
                'is_normal': anderson_stat < critical_values[2]
            }
        
        return {
            'normality_test': normality_test,
            'skewness': stats.skew(clean_data),
            'kurtosis': stats.kurtosis(clean_data),
            'jarque_bera_stat': stats.jarque_bera(clean_data)[0],
            'jarque_bera_p': stats.jarque_bera(clean_data)[1]
        }
