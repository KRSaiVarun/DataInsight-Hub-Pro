import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional
import json
import os
from openai import OpenAI

class InsightGenerator:
    """Generate automated insights and natural language summaries from data analysis."""
    
    def __init__(self):
        """Initialize the insight generator with OpenAI client if available."""
        self.openai_client = None
        api_key = os.getenv('OPENAI_API_KEY')
        
        if api_key:
            try:
                self.openai_client = OpenAI(api_key=api_key)
            except Exception:
                self.openai_client = None
    
    def generate_data_insights(self, data: pd.DataFrame, processed_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate comprehensive insights about the dataset."""
        insights = {
            'overview': self._generate_overview_insights(data, processed_data),
            'patterns': self._detect_patterns(data, processed_data),
            'anomalies': self._detect_anomalies(data, processed_data),
            'recommendations': self._generate_recommendations(data, processed_data),
            'summary': self._generate_ai_summary(data, processed_data) if self.openai_client else None
        }
        
        return insights
    
    def _generate_overview_insights(self, data: pd.DataFrame, processed_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate basic overview insights about the dataset."""
        numerical_cols = processed_data.get('numerical_columns', [])
        categorical_cols = processed_data.get('categorical_columns', [])
        date_cols = processed_data.get('date_columns', [])
        
        overview = {
            'dataset_size': {
                'rows': len(data),
                'columns': len(data.columns),
                'memory_usage': data.memory_usage(deep=True).sum()
            },
            'column_types': {
                'numerical': len(numerical_cols),
                'categorical': len(categorical_cols),
                'date': len(date_cols)
            },
            'missing_data': {
                'total_missing': data.isnull().sum().sum(),
                'columns_with_missing': len(data.columns[data.isnull().any()]),
                'missing_percentage': (data.isnull().sum().sum() / data.size) * 100
            },
            'data_quality': self._assess_data_quality(data)
        }
        
        return overview
    
    def _detect_patterns(self, data: pd.DataFrame, processed_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Detect interesting patterns in the data."""
        patterns = []
        numerical_cols = processed_data.get('numerical_columns', [])
        categorical_cols = processed_data.get('categorical_columns', [])
        
        # Correlation patterns
        if len(numerical_cols) >= 2:
            corr_matrix = data[numerical_cols].corr()
            strong_correlations = []
            
            for i in range(len(corr_matrix.columns)):
                for j in range(i+1, len(corr_matrix.columns)):
                    corr_value = corr_matrix.iloc[i, j]
                    if abs(corr_value) > 0.7:  # Strong correlation threshold
                        strong_correlations.append({
                            'column1': corr_matrix.columns[i],
                            'column2': corr_matrix.columns[j],
                            'correlation': round(corr_value, 3),
                            'strength': 'Strong' if abs(corr_value) > 0.8 else 'Moderate'
                        })
            
            if strong_correlations:
                patterns.append({
                    'type': 'correlation',
                    'title': 'Strong Correlations Detected',
                    'description': f'Found {len(strong_correlations)} strong correlations between numerical variables',
                    'details': strong_correlations
                })
        
        # Distribution patterns
        for col in numerical_cols[:20]:  # Increased limit to 20 columns
            if col in data.columns and not data[col].empty:
                skewness = data[col].skew()
                if pd.notna(skewness) and abs(skewness) > 1:
                    patterns.append({
                        'type': 'distribution',
                        'title': f'Skewed Distribution in {col}',
                        'description': f'Column {col} shows {"right" if skewness > 0 else "left"} skewness (skewness: {skewness:.2f})',
                        'details': {'column': col, 'skewness': round(skewness, 3)}
                    })
        
        # Categorical patterns
        for col in categorical_cols[:15]:  # Increased limit to 15 columns
            if col in data.columns:
                value_counts = data[col].value_counts()
                if len(value_counts) > 0:
                    top_category_pct = (value_counts.iloc[0] / len(data)) * 100
                    if top_category_pct > 80:
                        patterns.append({
                            'type': 'categorical_dominance',
                            'title': f'Dominant Category in {col}',
                            'description': f'One category dominates {top_category_pct:.1f}% of values in {col}',
                            'details': {
                                'column': col,
                                'dominant_category': value_counts.index[0],
                                'percentage': round(top_category_pct, 1)
                            }
                        })
        
        return patterns
    
    def _detect_anomalies(self, data: pd.DataFrame, processed_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Detect anomalies and outliers in the data."""
        anomalies = []
        numerical_cols = processed_data.get('numerical_columns', [])
        
        for col in numerical_cols[:20]:  # Increased limit to 20 columns
            if col in data.columns and not data[col].empty:
                # IQR method for outlier detection
                Q1 = data[col].quantile(0.25)
                Q3 = data[col].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                
                outliers = data[(data[col] < lower_bound) | (data[col] > upper_bound)]
                outlier_count = len(outliers)
                
                if outlier_count > 0:
                    outlier_percentage = (outlier_count / len(data)) * 100
                    anomalies.append({
                        'type': 'outliers',
                        'title': f'Outliers Detected in {col}',
                        'description': f'Found {outlier_count} outliers ({outlier_percentage:.1f}%) in {col}',
                        'details': {
                            'column': col,
                            'outlier_count': outlier_count,
                            'percentage': round(outlier_percentage, 1),
                            'bounds': {'lower': round(lower_bound, 2), 'upper': round(upper_bound, 2)}
                        }
                    })
        
        # Missing data anomalies
        missing_data = data.isnull().sum()
        columns_with_high_missing = missing_data[missing_data > len(data) * 0.5]
        
        if len(columns_with_high_missing) > 0:
            anomalies.append({
                'type': 'missing_data',
                'title': 'High Missing Data',
                'description': f'{len(columns_with_high_missing)} columns have more than 50% missing data',
                'details': {
                    'columns': [{'column': col, 'missing_count': int(count), 'percentage': round((count/len(data))*100, 1)} 
                               for col, count in columns_with_high_missing.items()]
                }
            })
        
        return anomalies
    
    def _generate_recommendations(self, data: pd.DataFrame, processed_data: Dict[str, Any]) -> List[Dict[str, str]]:
        """Generate actionable recommendations based on data analysis."""
        recommendations = []
        numerical_cols = processed_data.get('numerical_columns', [])
        categorical_cols = processed_data.get('categorical_columns', [])
        
        # Data quality recommendations
        missing_percentage = (data.isnull().sum().sum() / data.size) * 100
        if missing_percentage > 10:
            recommendations.append({
                'category': 'Data Quality',
                'title': 'Address Missing Data',
                'description': f'Your dataset has {missing_percentage:.1f}% missing values. Consider imputation strategies or removing incomplete records.',
                'priority': 'High' if missing_percentage > 30 else 'Medium'
            })
        
        # Analysis recommendations
        if len(numerical_cols) >= 3:
            recommendations.append({
                'category': 'Analysis',
                'title': 'Explore Multivariate Relationships',
                'description': 'With multiple numerical variables, consider clustering analysis or principal component analysis.',
                'priority': 'Medium'
            })
        
        if len(categorical_cols) >= 2:
            recommendations.append({
                'category': 'Analysis',
                'title': 'Cross-tabulation Analysis',
                'description': 'Analyze relationships between categorical variables using cross-tabulation and chi-square tests.',
                'priority': 'Medium'
            })
        
        # Visualization recommendations
        if len(data) > 10000:
            recommendations.append({
                'category': 'Visualization',
                'title': 'Consider Sampling for Large Dataset',
                'description': 'Large datasets may benefit from sampling for initial exploration and faster visualization.',
                'priority': 'Low'
            })
        
        return recommendations
    
    def _assess_data_quality(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Assess overall data quality."""
        total_cells = data.size
        missing_cells = data.isnull().sum().sum()
        duplicate_rows = data.duplicated().sum()
        
        quality_score = max(0, 100 - (missing_cells/total_cells)*100 - (duplicate_rows/len(data))*10)
        
        return {
            'quality_score': round(quality_score, 1),
            'completeness': round((1 - missing_cells/total_cells)*100, 1),
            'uniqueness': round((1 - duplicate_rows/len(data))*100, 1),
            'duplicate_rows': int(duplicate_rows)
        }
    
    def _generate_ai_summary(self, data: pd.DataFrame, processed_data: Dict[str, Any]) -> Optional[str]:
        """Generate AI-powered natural language summary of the dataset."""
        if not self.openai_client:
            return None
            
        try:
            # Prepare dataset summary for AI
            numerical_cols = processed_data.get('numerical_columns', [])
            categorical_cols = processed_data.get('categorical_columns', [])
            
            # Sample statistics
            stats_summary = {}
            for col in numerical_cols[:15]:  # Increased limit to 15 columns
                if col in data.columns:
                    stats_summary[col] = {
                        'mean': data[col].mean(),
                        'std': data[col].std(),
                        'min': data[col].min(),
                        'max': data[col].max()
                    }
            
            # Categorical summaries
            cat_summary = {}
            for col in categorical_cols[:10]:
                if col in data.columns:
                    top_values = data[col].value_counts().head(3)
                    cat_summary[col] = {
                        'unique_count': data[col].nunique(),
                        'top_categories': top_values.to_dict()
                    }
            
            prompt = f"""
            Analyze this dataset and provide a concise, insightful summary in natural language.
            
            Dataset Overview:
            - Rows: {len(data)}
            - Columns: {len(data.columns)}
            - Numerical columns: {len(numerical_cols)}
            - Categorical columns: {len(categorical_cols)}
            - Missing data: {(data.isnull().sum().sum() / data.size) * 100:.1f}%
            
            Numerical Statistics (sample): {json.dumps(stats_summary, default=str)}
            Categorical Summary (sample): {json.dumps(cat_summary, default=str)}
            
            Provide a 2-3 paragraph summary that:
            1. Describes the dataset's main characteristics
            2. Highlights key patterns or notable findings
            3. Suggests potential use cases or analysis directions
            
            Write in a professional but accessible tone, as if explaining to a business stakeholder.
            """
            
            if not self.openai_client:
                return None
                
            response = self.openai_client.chat.completions.create(
                model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
                messages=[
                    {"role": "system", "content": "You are a data analyst providing clear, actionable insights about datasets."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1000,
                temperature=0.7
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return None
    
    def generate_visualization_insights(self, chart_data: Dict[str, Any], chart_type: str) -> Optional[str]:
        """Generate insights about specific visualizations."""
        if not self.openai_client:
            return None
            
        try:
            prompt = f"""
            Analyze this {chart_type} visualization and provide key insights.
            
            Chart Type: {chart_type}
            Data Summary: {json.dumps(chart_data, default=str)[:1000]}  # Limit to prevent overflow
            
            Provide 2-3 key insights that a business user would find valuable.
            Focus on trends, patterns, outliers, or actionable findings.
            Keep it concise and business-focused.
            """
            
            if not self.openai_client:
                return None
                
            response = self.openai_client.chat.completions.create(
                model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
                messages=[
                    {"role": "system", "content": "You are a data visualization expert providing actionable insights."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                temperature=0.7
            )
            
            return response.choices[0].message.content
            
        except Exception:
            return None