import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import io
import time
from utils.data_processor import DataProcessor
from utils.visualizations import Visualizations
from utils.statistics import Statistics
from utils.resume_analyzer import ResumeAnalyzer
from utils.insight_generator import InsightGenerator

# Configure page
st.set_page_config(
    page_title="DataInsight Hub",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for modern dark theme styling
st.markdown("""
<style>
    /* Main container styling */
    .main > div {
        padding-top: 2rem;
    }
    
    /* Header styling */
    .main-header {
        background: linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%);
        padding: 2rem;
        border-radius: 15px;
        margin-bottom: 2rem;
        color: white;
        text-align: center;
        box-shadow: 0 8px 32px rgba(255, 107, 107, 0.3);
    }
    
    /* Metric cards */
    .metric-card {
        background: linear-gradient(135deg, #262730 0%, #3A3B47 100%);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        border-left: 4px solid #FF6B6B;
        margin: 1rem 0;
        color: #FAFAFA;
    }
    
    /* Tab styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
    }
    
    .stTabs [data-baseweb="tab-list"] button {
        background-color: #262730 !important;
        color: #FAFAFA !important;
        border-radius: 12px 12px 0 0 !important;
        border: 2px solid #FF6B6B !important;
        font-weight: 600 !important;
    }
    
    .stTabs [data-baseweb="tab-list"] button[aria-selected="true"] {
        background: linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%) !important;
        color: white !important;
    }
    
    /* Sidebar styling */
    .css-1d391kg {
        background: linear-gradient(180deg, #1E1E2E 0%, #262730 100%);
    }
    
    /* Success message styling */
    .success-message {
        background: linear-gradient(135deg, #4ECDC4, #44A08D);
        color: white;
        padding: 1rem;
        border-radius: 12px;
        margin: 1rem 0;
        text-align: center;
        font-weight: 600;
        box-shadow: 0 4px 16px rgba(78, 205, 196, 0.3);
    }
    
    /* Loading spinner */
    .loading-container {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 2rem;
    }
    
    /* Chart container styling */
    .chart-container {
        background: linear-gradient(135deg, #262730 0%, #3A3B47 100%);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        margin: 1rem 0;
        border: 1px solid #FF6B6B;
    }
    
    /* Data table styling */
    .dataframe {
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        border: 1px solid #FF6B6B;
    }
    
    /* Button styling */
    .stButton > button {
        background: linear-gradient(135deg, #FF6B6B, #4ECDC4) !important;
        color: white !important;
        border: none !important;
        border-radius: 12px !important;
        padding: 0.75rem 1.5rem !important;
        font-weight: 600 !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 4px 16px rgba(255, 107, 107, 0.3) !important;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 24px rgba(255, 107, 107, 0.4) !important;
    }
    
    /* Expander styling */
    .streamlit-expanderHeader {
        background: linear-gradient(135deg, #262730 0%, #3A3B47 100%) !important;
        border-radius: 12px !important;
        border: 1px solid #FF6B6B !important;
    }
    
    /* File uploader styling */
    .stFileUploader > div > div {
        background: linear-gradient(135deg, #262730 0%, #3A3B47 100%) !important;
        border: 2px dashed #FF6B6B !important;
        border-radius: 12px !important;
    }
    
    /* Selectbox styling */
    .stSelectbox > div > div {
        background: linear-gradient(135deg, #262730 0%, #3A3B47 100%) !important;
        border: 1px solid #FF6B6B !important;
        border-radius: 8px !important;
    }
    
    /* Progress bar styling */
    .stProgress > div > div {
        background: linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%) !important;
    }
    
    /* Hide Streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_and_process_data(file_content, file_name):
    """Cache data loading and processing for better performance."""
    processor = DataProcessor()
    
    # Create a temporary file-like object
    import io
    file_obj = io.BytesIO(file_content)
    file_obj.name = file_name
    
    data = processor.load_file(file_obj)
    processed_data = processor.process_data(data)
    # Fix Arrow compatibility issues to prevent serialization errors
    data = processor.fix_arrow_compatibility(data)
    return data, processed_data

def main():
    # Modern header
    st.markdown("""
    <div class="main-header">
        <h1>📊 DataInsight Hub Pro</h1>
        <p>Advanced data analysis with lightning-fast insights and beautiful visualizations</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Initialize session state
    if 'data' not in st.session_state:
        st.session_state.data = None
    if 'processed_data' not in st.session_state:
        st.session_state.processed_data = None
    if 'file_processed' not in st.session_state:
        st.session_state.file_processed = False
    
    # Sidebar for file upload and controls
    with st.sidebar:
        st.markdown("### 📁 Data Upload")
        st.markdown("Upload your data file to get started with advanced analytics")
        
        uploaded_file = st.file_uploader(
            "Choose a CSV or Excel file",
            type=['csv', 'xlsx', 'xls'],
            help="Supports CSV, Excel (.xlsx, .xls) files up to 500MB"
        )
        
        if uploaded_file is not None:
            # Check if this is a new file
            file_id = f"{uploaded_file.name}_{uploaded_file.size}"
            
            if not st.session_state.file_processed or st.session_state.get('current_file_id') != file_id:
                try:
                    with st.spinner("🚀 Processing file..."):
                        progress_bar = st.progress(0)
                        
                        # Read file content
                        file_content = uploaded_file.read()
                        progress_bar.progress(30)
                        
                        # Process data using cached function
                        data, processed_data = load_and_process_data(file_content, uploaded_file.name)
                        progress_bar.progress(70)
                        
                        # Update session state
                        st.session_state.data = data
                        st.session_state.processed_data = processed_data
                        st.session_state.file_processed = True
                        st.session_state.current_file_id = file_id
                        progress_bar.progress(100)
                        
                        time.sleep(0.5)  # Small delay for visual feedback
                    
                    st.markdown("""
                    <div class="success-message">
                        ✅ File processed successfully!
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # File info in styled metrics
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("📊 Rows", f"{len(data):,}")
                    with col2:
                        st.metric("📈 Columns", len(data.columns))
                    
                    st.metric("💾 Size", f"{uploaded_file.size / 1024:.1f} KB")
                    
                    # Quick data preview
                    with st.expander("📋 Quick Preview", expanded=False):
                        display_preview = processor.fix_arrow_compatibility(data.head(10))
                        st.dataframe(display_preview, use_container_width=True)
                    
                except Exception as e:
                    st.error(f"❌ Error processing file: {str(e)}")
                    st.session_state.data = None
                    st.session_state.processed_data = None
                    st.session_state.file_processed = False
            
            # File info for already processed files
            elif st.session_state.data is not None:
                data = st.session_state.data
                st.success("✅ File ready for analysis!")
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("📊 Rows", f"{len(data):,}")
                with col2:
                    st.metric("📈 Columns", len(data.columns))
    
    # Main content area
    if st.session_state.data is not None:
        data = st.session_state.data
        processed_data = st.session_state.processed_data
        
        # Create tabs for different sections
        tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
            "📋 Data Preview", 
            "📈 Summary Statistics", 
            "📊 Visualizations", 
            "🔗 Correlations", 
            "📉 Trends",
            "🧠 AI Insights",
            "💼 Resume Matcher"
        ])
        
        with tab1:
            show_data_preview(data)
        
        with tab2:
            show_statistics(data, processed_data)
        
        with tab3:
            show_visualizations(data, processed_data)
        
        with tab4:
            show_correlations(data, processed_data)
        
        with tab5:
            show_trends(data, processed_data)
        
        with tab6:
            show_ai_insights(data, processed_data)
        
        with tab7:
            show_resume_matcher(data)
    
    else:
        # Modern welcome screen
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.markdown("""
            <div style="text-align: center; padding: 3rem 0;">
                <h2 style="color: #667eea; margin-bottom: 2rem;">🚀 Ready to Discover Insights?</h2>
                <p style="font-size: 1.2rem; color: #6c757d; margin-bottom: 2rem;">
                    Upload your data file to unlock powerful analytics
                </p>
            </div>
            """, unsafe_allow_html=True)
            
            # Feature showcase
            features = [
                ("📋 Smart Data Preview", "Advanced filtering and intelligent data exploration"),
                ("📈 Lightning Analytics", "Instant statistics with advanced metrics"),
                ("📊 Interactive Charts", "Beautiful, responsive visualizations"),
                ("🔗 Correlation Discovery", "Uncover hidden relationships in your data"),
                ("📉 Trend Analysis", "Time-series insights and forecasting"),
                ("🧠 AI Insights", "Automated insight generation with natural language summaries"),
                ("💼 Resume Matcher", "AI-powered resume analysis and company matching"),
                ("⚡ Real-time Processing", "Optimized for speed and performance")
            ]
            
            for title, desc in features:
                st.markdown(f"""
                <div class="metric-card">
                    <h4 style="color: #667eea; margin: 0 0 0.5rem 0;">{title}</h4>
                    <p style="color: #6c757d; margin: 0;">{desc}</p>
                </div>
                """, unsafe_allow_html=True)
            
            st.markdown("""
            <div style="text-align: center; margin-top: 2rem; padding: 1rem; background: #f8f9fa; border-radius: 8px;">
                <strong>Supported formats:</strong> CSV, Excel (.xlsx, .xls) • Max size: 500MB
            </div>
            """, unsafe_allow_html=True)

@st.cache_data
def get_data_sample(data, selected_columns, row_limit):
    """Cache data filtering for better performance."""
    return data[selected_columns].head(row_limit)

def show_data_preview(data):
    st.markdown("### 📋 Smart Data Preview")
    
    # Top metrics in cards
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("📊 Total Rows", f"{len(data):,}")
    with col2:
        st.metric("📈 Columns", len(data.columns))
    with col3:
        memory_mb = data.memory_usage(deep=True).sum() / (1024 * 1024)
        st.metric("💾 Memory", f"{memory_mb:.1f} MB")
    with col4:
        missing_count = data.isnull().sum().sum()
        st.metric("⚠️ Missing Values", f"{missing_count:,}")
    
    st.markdown("---")
    
    # Enhanced filtering
    col1, col2 = st.columns([3, 1])
    
    with col2:
        st.markdown("#### 🎛️ Filter Controls")
        
        # Smart column selection with search
        all_columns = list(data.columns)
        column_search = st.text_input("🔍 Search columns", placeholder="Type to filter columns...")
        
        if column_search:
            filtered_columns = [col for col in all_columns if column_search.lower() in col.lower()]
        else:
            filtered_columns = all_columns
        
        selected_columns = st.multiselect(
            "Select columns to display",
            options=filtered_columns,
            default=filtered_columns[:20] if len(filtered_columns) > 20 else filtered_columns,
            help="Choose which columns to display"
        )
        
        # Advanced row controls
        col_a, col_b = st.columns(2)
        with col_a:
            row_limit = st.selectbox(
                "Rows to show",
                [50, 100, 250, 500, 1000, 2500, 5000],
                index=2,
                help="Number of rows to display"
            )
        with col_b:
            start_row = st.number_input(
                "Start from row",
                min_value=0,
                max_value=max(0, len(data) - row_limit),
                value=0,
                help="Starting row number"
            )
        
        # Data type filter
        if st.checkbox("🔢 Show only numeric columns"):
            numeric_cols = data.select_dtypes(include=[np.number]).columns.tolist()
            selected_columns = [col for col in selected_columns if col in numeric_cols]
        
        # Quick actions
        st.markdown("#### ⚡ Quick Actions")
        if st.button("📋 Show All Columns", help="Display all columns"):
            selected_columns = all_columns
        if st.button("🔢 Numeric Only", help="Show only numeric columns"):
            selected_columns = data.select_dtypes(include=[np.number]).columns.tolist()
    
    with col1:
        if selected_columns:
            # Get filtered data using cached function
            filtered_data = get_data_sample(data, selected_columns, row_limit)
            
            # Enhanced dataframe display
            st.markdown("#### 📊 Data Table")
            display_filtered = processor.fix_arrow_compatibility(filtered_data.iloc[start_row:start_row + row_limit])
            st.dataframe(
                display_filtered,
                use_container_width=True,
                height=400
            )
            
            # Column statistics preview
            st.markdown("#### 📈 Column Statistics")
            numeric_cols = filtered_data.select_dtypes(include=[np.number]).columns
            if len(numeric_cols) > 0:
                stats_preview = filtered_data[numeric_cols].describe().round(2)
                display_stats = processor.fix_arrow_compatibility(stats_preview)
                st.dataframe(display_stats, use_container_width=True)
            else:
                st.info("No numeric columns selected for statistics preview")
        else:
            st.warning("Please select at least one column to display")

@st.cache_data
def calculate_numerical_statistics(data, numerical_cols):
    """Cache statistical calculations for better performance."""
    stats = Statistics()
    return stats.calculate_numerical_stats(data[numerical_cols])

@st.cache_data
def get_categorical_analysis(data, col, limit=10):
    """Cache categorical analysis for better performance."""
    return data[col].value_counts().head(min(limit, 50))

def show_statistics(data, processed_data):
    st.markdown("### 📈 Lightning Analytics")
    
    numerical_cols = processed_data['numerical_columns']
    categorical_cols = processed_data['categorical_columns']
    
    # Quick overview metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("🔢 Numeric Columns", len(numerical_cols))
    with col2:
        st.metric("📝 Categorical Columns", len(categorical_cols))
    with col3:
        date_cols = processed_data.get('date_columns', [])
        st.metric("📅 Date Columns", len(date_cols))
    with col4:
        missing_percentage = (data.isnull().sum().sum() / (len(data) * len(data.columns))) * 100
        st.metric("⚠️ Missing Data", f"{missing_percentage:.1f}%")
    
    # Tabbed interface for different statistics
    tab1, tab2, tab3 = st.tabs(["🔢 Numerical Analysis", "📝 Categorical Analysis", "📊 Advanced Stats"])
    
    with tab1:
        if numerical_cols:
            st.markdown("#### 📊 Comprehensive Numerical Statistics")
            
            # Calculate statistics using cached function
            with st.spinner("Calculating numerical statistics..."):
                numerical_stats = calculate_numerical_statistics(data, numerical_cols)
            
            # Interactive statistics table
            st.dataframe(
                numerical_stats,
                use_container_width=True,
                height=400
            )
            
            # Download options
            col1, col2, col3 = st.columns(3)
            with col1:
                csv_buffer = io.StringIO()
                numerical_stats.to_csv(csv_buffer)
                st.download_button(
                    label="📥 Download CSV",
                    data=csv_buffer.getvalue(),
                    file_name="numerical_statistics.csv",
                    mime="text/csv"
                )
            with col2:  
                excel_buffer = io.BytesIO()
                try:
                    with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                        numerical_stats.to_excel(writer, index=True)
                    
                    st.download_button(
                        label="📊 Download Excel",
                        data=excel_buffer.getvalue(),
                        file_name="numerical_statistics.xlsx", 
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
                except Exception as e:
                    st.error(f"Error creating Excel file: {e}")
            with col3:
                json_data = numerical_stats.to_json(orient='index')
                if json_data:
                    st.download_button(
                        label="🔗 Download JSON",
                        data=json_data,
                        file_name="numerical_statistics.json",
                        mime="application/json"
                    )
        else:
            st.info("No numerical columns found for analysis")
    
    with tab2:
        if categorical_cols:
            st.markdown("#### 📝 Categorical Data Analysis")
            
            # Column selector for categorical analysis
            selected_cat_cols = st.multiselect(
                "Select categorical columns to analyze",
                categorical_cols,
                default=categorical_cols[:10] if len(categorical_cols) > 10 else categorical_cols
            )
            
            if selected_cat_cols:
                for i, col in enumerate(selected_cat_cols):
                    with st.expander(f"📊 Analysis for: {col}", expanded=i == 0):
                        col1, col2 = st.columns([2, 1])
                        
                        with col1:
                            # Get value counts using cached function
                            value_counts = get_categorical_analysis(data, col, 10)
                            
                            # Enhanced bar chart
                            fig = px.bar(
                                x=value_counts.values,
                                y=value_counts.index,
                                orientation='h',
                                title=f"Top 10 Categories in {col}",
                                color=value_counts.values,
                                color_continuous_scale='viridis',
                                text=value_counts.values
                            )
                            fig.update_traces(texttemplate='%{text}', textposition='outside')
                            fig.update_layout(
                                height=400,
                                showlegend=False,
                                coloraxis_showscale=False
                            )
                            st.plotly_chart(fig, use_container_width=True)
                        
                        with col2:
                            st.markdown("**📈 Statistics**")
                            total_unique = data[col].nunique()
                            most_common = value_counts.index[0]
                            most_common_count = value_counts.iloc[0]
                            
                            st.metric("Unique Values", total_unique)
                            st.metric("Most Common", most_common)
                            st.metric("Frequency", f"{most_common_count:,}")
                            st.metric("Percentage", f"{(most_common_count/len(data)*100):.1f}%")
                            
                            st.markdown("**📊 Value Counts**")
                            st.dataframe(
                                value_counts.to_frame('Count').assign(
                                    Percentage=lambda x: (x['Count'] / len(data) * 100).round(2)
                                ),
                                height=200
                            )
        else:
            st.info("No categorical columns found for analysis")
    
    with tab3:
        st.markdown("#### 📊 Advanced Statistical Analysis")
        
        if numerical_cols:
            selected_col = st.selectbox("Select column for advanced analysis", numerical_cols)
            
            if selected_col:
                col_data = data[selected_col].dropna()
                
                # Distribution analysis
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("**📈 Distribution Metrics**")
                    stats_obj = Statistics()
                    dist_stats = stats_obj.calculate_distribution_stats(col_data)
                    
                    if dist_stats:
                        normality_test = dist_stats.get('normality_test', {})
                        is_normal = normality_test.get('is_normal', False)
                        
                        st.metric("Normal Distribution", "Yes ✅" if is_normal else "No ❌")
                        st.metric("Skewness", f"{dist_stats.get('skewness', 0):.4f}")
                        st.metric("Kurtosis", f"{dist_stats.get('kurtosis', 0):.4f}")
                
                with col2:
                    st.markdown("**🎯 Outlier Detection**")
                    outlier_results = stats_obj.detect_outliers(col_data, method='iqr')
                    
                    st.metric("Outliers Found", outlier_results['outlier_count'])
                    st.metric("Outlier %", f"{outlier_results['outlier_percentage']:.2f}%")
                    st.metric("Lower Bound", f"{outlier_results['lower_bound']:.4f}")
                    st.metric("Upper Bound", f"{outlier_results['upper_bound']:.4f}")
        else:
            st.info("No numerical columns available for advanced analysis")

@st.cache_data
def create_cached_visualization(data_dict, viz_type, **kwargs):
    """Cache visualization creation for better performance."""
    import pandas as pd
    data = pd.DataFrame(data_dict)
    viz = Visualizations()
    
    if viz_type == "histogram":
        return viz.create_histogram(data, kwargs['column'], kwargs.get('bins', 30))
    elif viz_type == "box_plot":
        return viz.create_box_plot(data, kwargs['columns'])
    elif viz_type == "scatter_plot":
        return viz.create_scatter_plot(data, kwargs['x_col'], kwargs['y_col'], kwargs.get('color_col'))
    elif viz_type == "line_chart":
        return viz.create_line_chart(data, kwargs.get('date_col'), kwargs['value_col'])
    elif viz_type == "distribution_comparison":
        return viz.create_distribution_comparison(data, kwargs['columns'])
    elif viz_type == "correlation_heatmap":
        return viz.create_correlation_heatmap(kwargs['correlation_matrix'])

def show_visualizations(data, processed_data):
    st.markdown("### 📊 Interactive Visualizations")
    
    numerical_cols = processed_data['numerical_columns']
    categorical_cols = processed_data['categorical_columns']
    
    if len(numerical_cols) == 0:
        st.warning("⚠️ No numerical columns found for visualization.")
        return
    
    # Enhanced visualization controls
    col1, col2 = st.columns([2, 1])
    
    with col2:
        st.markdown("#### 🎛️ Visualization Controls")
        
        # Visualization type with icons
        viz_options = {
            "📊 Histogram": "histogram",
            "📦 Box Plot": "box_plot", 
            "🔵 Scatter Plot": "scatter_plot",
            "📈 Line Chart": "line_chart",
            "📊 Distribution Comparison": "distribution_comparison",
            "🌈 Correlation Heatmap": "correlation_heatmap"
        }
        
        selected_viz = st.selectbox(
            "Choose visualization type",
            list(viz_options.keys()),
            help="Select the type of chart you want to create"
        )
        viz_type = viz_options[selected_viz]
        
        # Dynamic controls based on visualization type
        st.markdown("---")
        
    with col1:
        # Convert data to dict for caching
        data_dict = data.to_dict('list')
        
        # Visualization rendering based on type
        if viz_type == "histogram":
            with col2:
                column = st.selectbox("Select column", numerical_cols)
                bins = st.slider("Number of bins", 10, 100, 30)
                show_stats = st.checkbox("Show statistics overlay", True)
            
            if column:
                with st.spinner("Creating histogram..."):
                    fig = create_cached_visualization(
                        data_dict, "histogram", 
                        column=column, bins=bins
                    )
                    
                    if show_stats:
                        mean_val = data[column].mean()
                        median_val = data[column].median()
                        fig.add_vline(x=mean_val, line_dash="dash", line_color="red", 
                                     annotation_text=f"Mean: {mean_val:.2f}")
                        fig.add_vline(x=median_val, line_dash="dash", line_color="blue", 
                                     annotation_text=f"Median: {median_val:.2f}")
                    
                    st.plotly_chart(fig, use_container_width=True)
        
        elif viz_type == "box_plot":
            with col2:
                columns = st.multiselect(
                    "Select columns", numerical_cols,
                    default=numerical_cols[:3] if len(numerical_cols) >= 3 else numerical_cols
                )
                show_outliers = st.checkbox("Show outliers", True)
            
            if columns:
                with st.spinner("Creating box plot..."):
                    fig = create_cached_visualization(data_dict, "box_plot", columns=columns)
                    if not show_outliers:
                        fig.update_traces(boxpoints=False)
                    st.plotly_chart(fig, use_container_width=True)
        
        elif viz_type == "scatter_plot":
            if len(numerical_cols) >= 2:
                with col2:
                    x_col = st.selectbox("X-axis", numerical_cols, index=0)
                    y_col = st.selectbox("Y-axis", numerical_cols, index=1)
                    
                    color_col = None
                    if categorical_cols:
                        use_color = st.checkbox("Color by category")
                        if use_color:
                            color_col = st.selectbox("Color by", categorical_cols)
                    
                    show_trend = st.checkbox("Show trend line", True)
                
                with st.spinner("Creating scatter plot..."):
                    fig = create_cached_visualization(
                        data_dict, "scatter_plot",
                        x_col=x_col, y_col=y_col, color_col=color_col
                    )
                    if not show_trend:
                        # Remove trend line if it exists
                        fig.data = [trace for trace in fig.data if trace.name != 'Trend Line']
                    st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("Need at least 2 numerical columns for scatter plot")
        
        elif viz_type == "line_chart":
            with col2:
                value_col = st.selectbox("Value column", numerical_cols)
                date_cols = processed_data.get('date_columns', [])
                
                if date_cols:
                    date_col = st.selectbox("Date column", date_cols)
                    smoothing = st.checkbox("Apply smoothing")
                else:
                    st.info("No date columns found, using index")
                    date_col = None
                    smoothing = st.checkbox("Apply smoothing")
            
            if value_col:
                with st.spinner("Creating line chart..."):
                    fig = create_cached_visualization(
                        data_dict, "line_chart",
                        date_col=date_col, value_col=value_col
                    )
                    
                    if smoothing and len(data) > 10:
                        # Add smoothed line
                        from scipy.signal import savgol_filter
                        if len(data) > 10:
                            window_length = min(11, len(data) // 4)
                            if window_length % 2 == 0:
                                window_length += 1
                            filled_data = data[value_col].ffill().bfill()
                            smoothed = savgol_filter(filled_data, window_length, 3)
                            
                            fig.add_trace(go.Scatter(
                                x=data.index if date_col is None else data[date_col],
                                y=smoothed,
                                mode='lines',
                                name='Smoothed Trend',
                                line=dict(dash='dash', color='orange', width=3)
                            ))
                    
                    st.plotly_chart(fig, use_container_width=True)
        
        elif viz_type == "distribution_comparison":
            with col2:
                columns = st.multiselect(
                    "Select columns to compare", numerical_cols,
                    default=numerical_cols[:3] if len(numerical_cols) >= 3 else numerical_cols
                )
                show_kde = st.checkbox("Show density curves", True)
            
            if columns:
                with st.spinner("Creating distribution comparison..."):
                    fig = create_cached_visualization(
                        data_dict, "distribution_comparison", columns=columns
                    )
                    st.plotly_chart(fig, use_container_width=True)
        
        elif viz_type == "correlation_heatmap":
            with col2:
                min_corr = st.slider("Minimum correlation threshold", 0.0, 1.0, 0.0, 0.1)
                show_values = st.checkbox("Show correlation values", True)
            
            if len(numerical_cols) >= 2:
                with st.spinner("Creating correlation heatmap..."):
                    stats = Statistics()
                    correlation_matrix = stats.calculate_correlation_matrix(data[numerical_cols])
                    
                    # Filter correlations below threshold
                    if min_corr > 0:
                        correlation_matrix = correlation_matrix.mask(
                            (correlation_matrix.abs() < min_corr) & (correlation_matrix != 1.0)
                        )
                    
                    fig = create_cached_visualization(
                        {}, "correlation_heatmap", correlation_matrix=correlation_matrix
                    )
                    
                    if not show_values:
                        fig.update_traces(text=None, texttemplate=None)
                    
                    st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("Need at least 2 numerical columns for correlation analysis")
    


@st.cache_data
def calculate_correlation_data(data, numerical_cols, threshold=0.7):
    """Cache correlation calculations for better performance."""
    stats = Statistics()
    correlation_matrix = stats.calculate_correlation_matrix(data[numerical_cols])
    strong_corr = stats.find_strong_correlations(correlation_matrix, threshold)
    return correlation_matrix, strong_corr

def show_correlations(data, processed_data):
    st.markdown("### 🔗 Correlation Discovery")
    
    numerical_cols = processed_data['numerical_columns']
    
    if len(numerical_cols) < 2:
        st.warning("⚠️ Need at least 2 numerical columns for correlation analysis.")
        return
    
    # Top metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("🔢 Variables", len(numerical_cols))
    with col2:
        total_pairs = len(numerical_cols) * (len(numerical_cols) - 1) // 2
        st.metric("🔗 Pairs", total_pairs)
    
    # Calculate correlations using cached function
    threshold = st.slider("Correlation threshold", 0.1, 1.0, 0.7, 0.1)
    
    with st.spinner("Analyzing correlations..."):
        correlation_matrix, strong_corr = calculate_correlation_data(data, numerical_cols, threshold)
    
    with col3:
        st.metric("💪 Strong Correlations", len(strong_corr))
    with col4:
        max_corr = correlation_matrix.abs().max().max()
        st.metric("📊 Max Correlation", f"{max_corr:.3f}")
    
    # Enhanced correlation heatmap
    st.markdown("#### 🌈 Interactive Correlation Heatmap")
    viz = Visualizations()
    fig = viz.create_correlation_heatmap(correlation_matrix)
    st.plotly_chart(fig, use_container_width=True)
    
    # Strong correlations with enhanced display
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("#### 💪 Strong Correlations")
        if not strong_corr.empty:
            # Display strong correlations
            st.dataframe(strong_corr, use_container_width=True)
            
            # Download correlation results
            csv_buffer = io.StringIO()
            strong_corr.to_csv(csv_buffer, index=False)
            st.download_button(
                label="📥 Download Strong Correlations",
                data=csv_buffer.getvalue(),
                file_name="strong_correlations.csv",
                mime="text/csv"
            )
        else:
            st.info(f"No correlations above {threshold:.1f} threshold found")
    
    with col2:
        st.markdown("#### 📈 Correlation Statistics")
        
        # Calculate correlation statistics
        corr_values = correlation_matrix.values
        upper_triangle = corr_values[np.triu_indices_from(corr_values, k=1)]
        
        st.metric("Mean Correlation", f"{np.mean(upper_triangle):.4f}")
        st.metric("Median Correlation", f"{np.median(upper_triangle):.4f}")
        st.metric("Std Correlation", f"{np.std(upper_triangle):.4f}")
        
        # Correlation strength distribution
        strong_count = np.sum(np.abs(upper_triangle) >= 0.7)
        moderate_count = np.sum((np.abs(upper_triangle) >= 0.3) & (np.abs(upper_triangle) < 0.7))
        weak_count = np.sum(np.abs(upper_triangle) < 0.3)
        
        st.markdown("**Strength Distribution:**")
        st.write(f"Strong (≥0.7): {strong_count}")
        st.write(f"Moderate (0.3-0.7): {moderate_count}")
        st.write(f"Weak (<0.3): {weak_count}")
    
    # Full correlation matrix with search
    with st.expander("🔍 Full Correlation Matrix", expanded=False):
        search_var = st.text_input("Search for variable", placeholder="Type variable name...")
        
        display_matrix = correlation_matrix
        if search_var:
            matching_cols = [col for col in correlation_matrix.columns if search_var.lower() in col.lower()]
            if matching_cols:
                display_matrix = correlation_matrix.loc[matching_cols, matching_cols]
        
        st.dataframe(display_matrix, use_container_width=True)

@st.cache_data
def calculate_trend_analysis(data, date_col, value_col, time_period="Daily"):
    """Cache trend analysis calculations."""
    viz = Visualizations()
    stats = Statistics()
    
    if date_col:
        plot_data = data.copy()
        plot_data[date_col] = pd.to_datetime(plot_data[date_col])
        plot_data = plot_data.sort_values(date_col)
        trend_stats = stats.calculate_trend_stats(plot_data[value_col].values)
    else:
        trend_stats = stats.calculate_trend_stats(data[value_col].values)
    
    return trend_stats

def show_trends(data, processed_data):
    st.markdown("### 📉 Advanced Trend Analysis")
    
    date_cols = processed_data.get('date_columns', [])
    numerical_cols = processed_data['numerical_columns']
    
    if not numerical_cols:
        st.warning("⚠️ No numerical columns available for trend analysis.")
        return
    
    # Top metrics
    col1, col2, col3, col4 = st.columns(4)
    
    # Enhanced trend analysis interface
    if not date_cols:
        st.info("💡 No date columns detected. Using row index for trend analysis.")
        
        # Column selection
        selected_col = st.selectbox("📊 Select column for trend analysis", numerical_cols)
        
        if selected_col:
            # Calculate trend statistics using cached function
            with st.spinner("Analyzing trends..."):
                trend_stats = calculate_trend_analysis(data, None, selected_col)
            
            # Display trend metrics
            with col1:
                direction_color = "🟢" if trend_stats['trend_direction'] == "Increasing" else "🔴" if trend_stats['trend_direction'] == "Decreasing" else "🟡"
                st.metric("Trend Direction", f"{direction_color} {trend_stats['trend_direction']}")
            with col2:
                st.metric("Slope", f"{trend_stats['slope']:.6f}")
            with col3:
                st.metric("R² Score", f"{trend_stats['r_squared']:.4f}")
            with col4:
                st.metric("Volatility", f"{trend_stats['volatility']:.4f}")
            
            # Create enhanced trend visualization
            viz = Visualizations()
            fig = viz.create_trend_analysis(data, None, selected_col)
            
            # Add advanced trend features
            if len(data) > 10:
                # Add moving averages
                window_sizes = [5, 10, 20] if len(data) > 20 else [3, 7]
                
                for window in window_sizes:
                    if len(data) >= window:
                        moving_avg = data[selected_col].rolling(window=window, center=True).mean()
                        fig.add_trace(go.Scatter(
                            x=data.index,
                            y=moving_avg,
                            mode='lines',
                            name=f'{window}-period MA',
                            line=dict(dash='dot', width=2),
                            opacity=0.7
                        ))
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Additional trend insights
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### 📈 Trend Insights")
                
                # Calculate additional statistics
                values = data[selected_col].dropna()
                if len(values) > 1:
                    pct_change = ((values.iloc[-1] - values.iloc[0]) / values.iloc[0]) * 100
                    st.metric("Total Change", f"{pct_change:.2f}%")
                    
                    # Trend strength interpretation
                    r_squared = trend_stats['r_squared']
                    if r_squared >= 0.7:
                        strength = "Very Strong"
                        strength_color = "🟢"
                    elif r_squared >= 0.5:
                        strength = "Strong"
                        strength_color = "🟡"
                    elif r_squared >= 0.3:
                        strength = "Moderate"
                        strength_color = "🟠"
                    else:
                        strength = "Weak"
                        strength_color = "🔴"
                    
                    st.metric("Trend Strength", f"{strength_color} {strength}")
            
            with col2:
                st.markdown("#### 📊 Statistical Summary")
                st.dataframe(
                    pd.DataFrame({
                        'Metric': ['Count', 'Mean', 'Std Dev', 'Min', 'Max'],
                        'Value': [
                            len(values),
                            f"{values.mean():.4f}",
                            f"{values.std():.4f}",
                            f"{values.min():.4f}",
                            f"{values.max():.4f}"
                        ]
                    }).set_index('Metric'),
                    use_container_width=True
                )
    
    else:
        # Time-based trend analysis
        st.success("📅 Date columns detected! Enhanced time-series analysis available.")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            date_col = st.selectbox("📅 Select date column", date_cols)
        with col2:
            value_col = st.selectbox("📊 Select value column", numerical_cols)
        with col3:
            time_period = st.selectbox(
                "⏱️ Time aggregation",
                ["Daily", "Weekly", "Monthly", "Quarterly", "Yearly"],
                index=0
            )
        
        if date_col and value_col:
            try:
                # Calculate trend statistics using cached function
                with st.spinner("Analyzing time-series trends..."):
                    trend_stats = calculate_trend_analysis(data, date_col, value_col, time_period)
                
                # Display enhanced metrics
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    direction_color = "🟢" if trend_stats['trend_direction'] == "Increasing" else "🔴" if trend_stats['trend_direction'] == "Decreasing" else "🟡"
                    st.metric("📈 Trend", f"{direction_color} {trend_stats['trend_direction']}")
                with col2:
                    st.metric("📊 Slope", f"{trend_stats['slope']:.6f}")
                with col3:
                    st.metric("🎯 R² Score", f"{trend_stats['r_squared']:.4f}")
                with col4:
                    st.metric("⚡ Volatility", f"{trend_stats['volatility']:.4f}")
                
                # Enhanced time-series visualization
                viz = Visualizations()
                fig = viz.create_trend_analysis(data, date_col, value_col, time_period)
                st.plotly_chart(fig, use_container_width=True)
                
                # Time-series insights
                st.markdown("#### 🔍 Time-Series Insights")
                
                time_series_data = data.copy()
                time_series_data[date_col] = pd.to_datetime(time_series_data[date_col])
                time_series_data = time_series_data.sort_values(date_col)
                
                # Calculate time-based statistics
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.markdown("**📅 Time Range**")
                    start_date = time_series_data[date_col].min()
                    end_date = time_series_data[date_col].max()
                    duration = (end_date - start_date).days
                    
                    st.write(f"Start: {start_date.strftime('%Y-%m-%d')}")
                    st.write(f"End: {end_date.strftime('%Y-%m-%d')}")
                    st.write(f"Duration: {duration} days")
                
                with col2:
                    st.markdown("**📈 Value Changes**")
                    first_value = time_series_data[value_col].iloc[0]
                    last_value = time_series_data[value_col].iloc[-1]
                    total_change = last_value - first_value
                    pct_change = (total_change / first_value) * 100 if first_value != 0 else 0
                    
                    st.write(f"Start Value: {first_value:.4f}")
                    st.write(f"End Value: {last_value:.4f}")
                    st.write(f"Change: {pct_change:.2f}%")
                
                with col3:
                    st.markdown("**📊 Trend Quality**")
                    p_value = trend_stats.get('p_value', 1.0)
                    significance = "Significant" if p_value < 0.05 else "Not Significant"
                    
                    st.write(f"P-value: {p_value:.4f}")
                    st.write(f"Significance: {significance}")
                    st.write(f"Confidence: {(1-p_value)*100:.1f}%")
                
            except Exception as e:
                st.error(f"❌ Error in trend analysis: {str(e)}")
                st.info("💡 Try selecting different columns or check your data format.")

@st.cache_data
def analyze_resume_cached(file_content, file_name):
    """Cache resume analysis for better performance."""
    import io
    file_obj = io.BytesIO(file_content)
    file_obj.name = file_name
    
    analyzer = ResumeAnalyzer()
    return analyzer.analyze_resume(file_obj)

def show_resume_matcher(companies_data):
    """Show resume analysis and company matching interface."""
    st.markdown("### 💼 AI-Powered Resume Matcher")
    
    st.markdown("""
    Upload your resume (PDF or DOCX) to get AI-powered analysis and discover companies 
    that match your skills and experience level. Our system analyzes your technical skills, 
    experience, and qualifications to find the best opportunities.
    """)
    
    # If no company data uploaded, provide sample data option
    if companies_data.empty:
        st.warning("⚠️ No company data loaded. Please upload your CSV file first, or try our sample data.")
        
        col1, col2 = st.columns([1, 1])
        with col1:
            if st.button("📋 Use Sample Company Data", help="Load sample companies for demonstration"):
                try:
                    sample_data = pd.read_csv('sample_company_data.csv')
                    st.session_state.data = sample_data
                    st.session_state.processed_data = DataProcessor().process_data(sample_data)
                    st.success("✅ Sample company data loaded! Please refresh to use it.")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error loading sample data: {str(e)}")
        
        with col2:
            st.info("💡 Upload your company database in the main Data Upload section to get personalized matches.")
        
        return
    
    # Resume upload section
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("#### 📄 Upload Your Resume")
        
        uploaded_resume = st.file_uploader(
            "Choose your resume file",
            type=['pdf', 'docx', 'doc'],
            help="Upload your resume in PDF or Word format for analysis"
        )
        
        if uploaded_resume is not None:
            try:
                with st.spinner("🔍 Analyzing your resume..."):
                    # Read file content for caching
                    file_content = uploaded_resume.read()
                    
                    # Analyze resume using cached function
                    resume_analysis = analyze_resume_cached(file_content, uploaded_resume.name)
                    
                    progress_bar = st.progress(0)
                    progress_bar.progress(50)
                    
                    # Match with companies
                    analyzer = ResumeAnalyzer()
                    matches = analyzer.match_with_companies(resume_analysis, companies_data)
                    
                    progress_bar.progress(80)
                    
                    # Generate recommendations
                    recommendations = analyzer.generate_recommendations(resume_analysis, matches)
                    
                    progress_bar.progress(100)
                    time.sleep(0.3)
                    progress_bar.empty()
                
                st.success("✅ Resume analysis completed!")
                
                # Display results in tabs
                result_tab1, result_tab2, result_tab3, result_tab4 = st.tabs([
                    "📊 Resume Analysis", 
                    "🏢 Company Matches", 
                    "💡 Recommendations", 
                    "📈 Skills Insights"
                ])
                
                with result_tab1:
                    show_resume_analysis(resume_analysis)
                
                with result_tab2:
                    show_company_matches(matches, companies_data)
                
                with result_tab3:
                    show_recommendations(recommendations)
                
                with result_tab4:
                    show_skills_insights(resume_analysis, companies_data)
            
            except Exception as e:
                st.error(f"❌ Error analyzing resume: {str(e)}")
                st.info("💡 Please ensure your resume is in PDF or DOCX format and contains readable text.")
    
    with col2:
        st.markdown("#### 📋 Analysis Features")
        
        features = [
            "🔍 Skill Extraction",
            "📊 Experience Level Detection", 
            "🎓 Education Analysis",
            "📞 Contact Information",
            "🏢 Company Matching",
            "💡 Career Recommendations",
            "📈 Skill Gap Analysis",
            "⭐ Match Scoring"
        ]
        
        for feature in features:
            st.markdown(f"• {feature}")
        
        st.markdown("---")
        st.markdown("#### 💡 Tips for Better Results")
        st.info("""
        • Use clear, readable fonts
        • Include specific technical skills
        • Mention years of experience
        • Add education details
        • Include contact information
        """)

def show_resume_analysis(analysis):
    """Display comprehensive resume analysis results."""
    st.markdown("#### 📊 Resume Analysis Results")
    
    # Basic metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("📝 Word Count", analysis.get('word_count', 0))
    with col2:
        st.metric("⏱️ Experience Level", analysis.get('experience_level', 'Unknown').title())
    with col3:
        total_skills = sum(len(skills) for skills in analysis.get('skills', {}).values())
        st.metric("🔧 Total Skills", total_skills)
    with col4:
        education_count = len(analysis.get('education', []))
        st.metric("🎓 Education Items", education_count)
    
    # Skills breakdown
    skills = analysis.get('skills', {})
    if skills:
        st.markdown("#### 🔧 Extracted Skills")
        
        for category, skill_list in skills.items():
            with st.expander(f"{category.replace('_', ' ').title()} ({len(skill_list)} skills)", expanded=True):
                # Create skill tags
                skill_tags = ""
                for skill in skill_list:
                    skill_tags += f'<span style="background: linear-gradient(45deg, #667eea, #764ba2); color: white; padding: 4px 8px; margin: 2px; border-radius: 12px; font-size: 12px; display: inline-block;">{skill}</span> '
                
                st.markdown(skill_tags, unsafe_allow_html=True)
    
    # Contact information
    contact_info = analysis.get('contact_info', {})
    if contact_info:
        st.markdown("#### 📞 Contact Information")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            if 'email' in contact_info:
                st.info(f"📧 {contact_info['email']}")
        with col2:
            if 'phone' in contact_info:
                st.info(f"📱 {contact_info['phone']}")
        with col3:
            if 'linkedin' in contact_info:
                st.info(f"💼 LinkedIn Found")
    
    # Education
    education = analysis.get('education', [])
    if education:
        st.markdown("#### 🎓 Education Keywords")
        education_text = ", ".join(education)
        st.text_area("Education found in resume:", education_text, height=100)

def show_company_matches(matches, companies_data):
    """Display company matching results."""
    st.markdown("#### 🏢 Top Company Matches")
    
    if matches.empty:
        st.warning("⚠️ No company matches found. This could mean:")
        st.info("""
        • Your resume skills don't match the company data columns
        • The company data may not contain detailed job requirements
        • Try adding more specific technical skills to your resume
        """)
        return
    
    # Top matches metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("🏢 Total Matches", len(matches))
    with col2:
        avg_score = matches['match_score'].mean()
        st.metric("📊 Avg Match Score", f"{avg_score:.1f}")
    with col3:
        best_match = matches.iloc[0]['match_score'] if not matches.empty else 0
        st.metric("⭐ Best Match Score", best_match)
    with col4:
        avg_skill_match = matches['skill_match_percentage'].mean() if 'skill_match_percentage' in matches.columns else 0
        st.metric("🎯 Avg Skill Match", f"{avg_skill_match:.1f}%")
    
    # Display top matches
    st.markdown("#### 🏆 Top 10 Company Matches")
    
    # Prepare display data
    display_matches = matches.head(25).copy()
    
    # Remove internal columns for display
    columns_to_remove = ['match_score', 'matched_skills', 'skill_match_percentage']
    display_columns = [col for col in display_matches.columns if col not in columns_to_remove]
    
    for i, (idx, match) in enumerate(display_matches.iterrows()):
        with st.expander(f"🏢 Match #{i + 1} - Score: {match['match_score']}", expanded=i == 0):
            
            # Company details
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.markdown("**📋 Company Information:**")
                for col in display_columns:
                    if pd.notna(match[col]) and str(match[col]).strip():
                        st.write(f"**{col}:** {match[col]}")
            
            with col2:
                st.markdown("**📊 Match Details:**")
                st.metric("Match Score", match['match_score'])
                st.metric("Skill Match %", f"{match['skill_match_percentage']:.1f}%")
                
                if match['matched_skills']:
                    st.markdown("**🎯 Matched Skills:**")
                    skills_text = ", ".join(match['matched_skills'][:5])  # Show first 5 skills
                    if len(match['matched_skills']) > 5:
                        skills_text += f" (+{len(match['matched_skills']) - 5} more)"
                    st.text(skills_text)
    
    # Download matches
    if not matches.empty:
        st.markdown("#### 💾 Export Results")
        
        col1, col2 = st.columns(2)
        
        with col1:
            csv_buffer = io.StringIO()
            matches.to_csv(csv_buffer, index=False)
            st.download_button(
                label="📥 Download Matches (CSV)",
                data=csv_buffer.getvalue(),
                file_name="company_matches.csv",
                mime="text/csv"
            )
        
        with col2:
            excel_buffer = io.BytesIO()
            try:
                with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                    matches.to_excel(writer, index=False)
                
                st.download_button(
                    label="📊 Download Matches (Excel)",
                    data=excel_buffer.getvalue(),
                    file_name="company_matches.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
            except Exception as e:
                st.error(f"Error creating Excel file: {e}")

def show_recommendations(recommendations):
    """Display career recommendations."""
    st.markdown("#### 💡 Career Recommendations")
    
    # Skill gaps
    skill_gaps = recommendations.get('skill_gaps', [])
    if skill_gaps:
        st.markdown("##### 🔧 Skill Gaps to Consider")
        st.info("These skills appear frequently in matching companies but are missing from your resume:")
        
        gap_tags = ""
        for skill in skill_gaps[:10]:  # Show top 10
            gap_tags += f'<span style="background: linear-gradient(45deg, #ff6b6b, #ee5a24); color: white; padding: 4px 8px; margin: 2px; border-radius: 12px; font-size: 12px; display: inline-block;">{skill}</span> '
        
        st.markdown(gap_tags, unsafe_allow_html=True)
    
    # Experience advice
    experience_advice = recommendations.get('experience_advice', '')
    if experience_advice:
        st.markdown("##### 📈 Experience Level Advice")
        st.success(experience_advice)
    
    # Improvement areas
    improvement_areas = recommendations.get('improvement_areas', [])
    if improvement_areas:
        st.markdown("##### 🎯 Resume Improvement Areas")
        for area in improvement_areas:
            st.warning(f"• {area}")
    
    # Career next steps (new AI feature)
    career_steps = recommendations.get('career_next_steps', [])
    if career_steps:
        st.markdown("##### 🚀 Career Next Steps")
        for step in career_steps:
            st.info(f"• {step}")
    
    # Top companies summary
    top_companies = recommendations.get('top_companies', [])
    if top_companies:
        st.markdown("##### 🏆 Top Recommended Companies")
        for i, company in enumerate(top_companies, 1):
            company_name = "Company" if not any(val for val in company.values() if isinstance(val, str) and len(str(val)) > 3) else list(company.values())[0]
            st.markdown(f"**{i}. {company_name}** - Match Score: {company.get('match_score', 0)}")

def show_skills_insights(resume_analysis, companies_data):
    """Display skills analysis and insights."""
    st.markdown("#### 📈 Skills Market Analysis")
    
    resume_skills = resume_analysis.get('skills', {})
    
    if not resume_skills:
        st.warning("No skills detected in resume for analysis.")
        return
    
    # Skills distribution
    st.markdown("##### 🔧 Your Skills Distribution")
    
    skill_counts = {category.replace('_', ' ').title(): len(skills) 
                   for category, skills in resume_skills.items()}
    
    # Create a simple bar chart
    categories = list(skill_counts.keys())
    counts = list(skill_counts.values())
    
    fig = go.Figure(data=[
        go.Bar(x=categories, y=counts, 
               marker_color=['#667eea', '#764ba2', '#f093fb', '#f5576c', '#4facfe'])
    ])
    
    fig.update_layout(
        title="Skills by Category",
        xaxis_title="Skill Categories", 
        yaxis_title="Number of Skills",
        showlegend=False,
        height=400
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Market demand analysis
    st.markdown("##### 📊 Market Demand Analysis")
    
    if not companies_data.empty:
        all_company_text = ' '.join([
            str(val) for val in companies_data.values.flatten() 
            if pd.notna(val)
        ]).lower()
        
        demand_analysis = {}
        all_resume_skills = []
        
        for category, skills in resume_skills.items():
            category_demand = 0
            for skill in skills:
                skill_mentions = all_company_text.count(skill.lower())
                category_demand += skill_mentions
                all_resume_skills.append((skill, skill_mentions))
            
            demand_analysis[category.replace('_', ' ').title()] = category_demand
        
        # Display demand by category
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**📈 Demand by Category:**")
            for category, demand in sorted(demand_analysis.items(), key=lambda x: x[1], reverse=True):
                st.metric(category, f"{demand} mentions")
        
        with col2:
            st.markdown("**🏆 Most In-Demand Skills:**")
            top_skills = sorted(all_resume_skills, key=lambda x: x[1], reverse=True)[:5]
            for skill, mentions in top_skills:
                if mentions > 0:
                    st.metric(skill.title(), f"{mentions} mentions")
    
    else:
        st.info("💡 Upload company data to see market demand analysis for your skills.")

    # End of resume analysis section

def show_ai_insights(data, processed_data):
    """Display AI-powered insights and natural language summaries."""
    st.markdown("#### 🧠 AI-Powered Data Insights")
    st.markdown("Get intelligent analysis and natural language summaries of your data.")
    
    # Generate insights
    with st.spinner("🔍 Analyzing your data and generating insights..."):
        insight_generator = InsightGenerator()
        insights = insight_generator.generate_data_insights(data, processed_data)
    
    # Display insights in organized sections
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # AI Summary
        if insights.get('summary'):
            st.markdown("#### 📝 Executive Summary")
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #262730 0%, #3A3B47 100%); 
                        padding: 1.5rem; border-radius: 12px; border-left: 4px solid #4ECDC4; 
                        margin: 1rem 0; color: #FAFAFA;">
                {insights['summary']}
            </div>
            """, unsafe_allow_html=True)
        else:
            st.info("💡 AI summary requires OpenAI API key. Add your key to get intelligent summaries.")
        
        # Patterns
        patterns = insights.get('patterns', [])
        if patterns:
            st.markdown("#### 🔍 Key Patterns Discovered")
            for i, pattern in enumerate(patterns):
                with st.expander(f"🔹 {pattern['title']}", expanded=i == 0):
                    st.write(pattern['description'])
                    if 'details' in pattern:
                        if pattern['type'] == 'correlation':
                            for corr in pattern['details'][:3]:  # Show top 3
                                strength_color = "#FF6B6B" if corr['strength'] == 'Strong' else "#FFA726"
                                st.markdown(f"""
                                <div style="background: rgba(255,107,107,0.1); padding: 0.5rem; 
                                           border-radius: 8px; margin: 0.3rem 0;">
                                    <strong>{corr['column1']}</strong> ↔ <strong>{corr['column2']}</strong><br>
                                    <span style="color: {strength_color}">Correlation: {corr['correlation']} ({corr['strength']})</span>
                                </div>
                                """, unsafe_allow_html=True)
        
        # Anomalies
        anomalies = insights.get('anomalies', [])
        if anomalies:
            st.markdown("#### ⚠️ Anomalies & Outliers")
            for anomaly in anomalies:
                with st.expander(f"⚠️ {anomaly['title']}", expanded=False):
                    st.warning(anomaly['description'])
                    if 'details' in anomaly and anomaly['type'] == 'outliers':
                        details = anomaly['details']
                        col_a, col_b, col_c = st.columns(3)
                        with col_a:
                            st.metric("Outlier Count", details['outlier_count'])
                        with col_b:
                            st.metric("Percentage", f"{details['percentage']}%")
                        with col_c:
                            st.metric("Bounds", f"{details['bounds']['lower']:.2f} - {details['bounds']['upper']:.2f}")
    
    with col2:
        # Overview metrics
        overview = insights.get('overview', {})
        if overview:
            st.markdown("#### 📊 Dataset Overview")
            
            # Dataset size
            dataset_size = overview.get('dataset_size', {})
            st.metric("📈 Rows", f"{dataset_size.get('rows', 0):,}")
            st.metric("📋 Columns", dataset_size.get('columns', 0))
            st.metric("💾 Memory", f"{dataset_size.get('memory_usage', 0) / 1024:.1f} KB")
            
            # Data quality
            quality = overview.get('data_quality', {})
            if quality:
                st.markdown("#### ✅ Data Quality")
                quality_score = quality.get('quality_score', 0)
                quality_color = "#4ECDC4" if quality_score > 80 else "#FFA726" if quality_score > 60 else "#FF6B6B"
                
                st.markdown(f"""
                <div style="text-align: center; padding: 1rem; background: linear-gradient(135deg, #262730 0%, #3A3B47 100%); 
                           border-radius: 12px; margin: 1rem 0; border: 2px solid {quality_color};">
                    <h2 style="color: {quality_color}; margin: 0;">{quality_score:.1f}/100</h2>
                    <p style="color: #FAFAFA; margin: 0;">Overall Quality Score</p>
                </div>
                """, unsafe_allow_html=True)
                
                st.metric("📊 Completeness", f"{quality.get('completeness', 0):.1f}%")
                st.metric("🔄 Uniqueness", f"{quality.get('uniqueness', 0):.1f}%")
                if quality.get('duplicate_rows', 0) > 0:
                    st.metric("⚠️ Duplicates", quality['duplicate_rows'])
            
            # Missing data
            missing_data = overview.get('missing_data', {})
            if missing_data:
                st.markdown("#### 🔍 Missing Data Analysis")
                st.metric("❌ Total Missing", missing_data.get('total_missing', 0))
                st.metric("📋 Affected Columns", missing_data.get('columns_with_missing', 0))
                missing_pct = missing_data.get('missing_percentage', 0)
                missing_color = "#4ECDC4" if missing_pct < 5 else "#FFA726" if missing_pct < 15 else "#FF6B6B"
                st.markdown(f"""
                <div style="background: rgba(255,107,107,0.1); padding: 0.5rem; border-radius: 8px; text-align: center;">
                    <span style="color: {missing_color}; font-weight: bold;">{missing_pct:.1f}%</span><br>
                    <small>Missing Data</small>
                </div>
                """, unsafe_allow_html=True)
    
    # Recommendations
    recommendations = insights.get('recommendations', [])
    if recommendations:
        st.markdown("#### 💡 Actionable Recommendations")
        
        # Group by priority
        high_priority = [r for r in recommendations if r.get('priority') == 'High']
        medium_priority = [r for r in recommendations if r.get('priority') == 'Medium']
        low_priority = [r for r in recommendations if r.get('priority') == 'Low']
        
        for priority, recs, color in [
            ('High Priority', high_priority, '#FF6B6B'),
            ('Medium Priority', medium_priority, '#FFA726'), 
            ('Low Priority', low_priority, '#4ECDC4')
        ]:
            if recs:
                st.markdown(f"##### {priority}")
                for rec in recs:
                    st.markdown(f"""
                    <div style="background: linear-gradient(135deg, #262730 0%, #3A3B47 100%); 
                               padding: 1rem; border-radius: 8px; margin: 0.5rem 0; 
                               border-left: 4px solid {color}; color: #FAFAFA;">
                        <strong>{rec['title']}</strong><br>
                        <small style="color: #B0B0B0;">{rec['category']}</small><br>
                        {rec['description']}
                    </div>
                    """, unsafe_allow_html=True)
    
    # Interactive insight generation
    st.markdown("#### 🎯 Custom Insight Generation")
    col1, col2 = st.columns(2)
    
    with col1:
        insight_type = st.selectbox(
            "What would you like to explore?",
            [
                "Overall Data Quality Assessment",
                "Correlation Deep Dive", 
                "Outlier Analysis",
                "Missing Data Strategy",
                "Feature Importance Analysis"
            ]
        )
    
    with col2:
        if st.button("🔍 Generate Custom Insight", type="primary"):
            with st.spinner("Generating custom insight..."):
                if insight_generator.openai_client:
                    # Generate specific insight based on selection
                    custom_prompt = f"Provide a detailed analysis focusing on {insight_type.lower()} for this dataset."
                    
                    try:
                        response = insight_generator.openai_client.chat.completions.create(
                            model="gpt-4o",
                            messages=[
                                {"role": "system", "content": "You are a data scientist providing detailed analysis."},
                                {"role": "user", "content": f"{custom_prompt}\n\nDataset: {len(data)} rows, {len(data.columns)} columns\nColumn types: {processed_data}"}
                            ],
                            max_tokens=800
                        )
                        
                        custom_insight = response.choices[0].message.content
                        st.markdown(f"""
                        <div style="background: linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%); 
                                   padding: 1.5rem; border-radius: 12px; margin: 1rem 0; color: white;">
                            <h5>🎯 {insight_type}</h5>
                            {custom_insight}
                        </div>
                        """, unsafe_allow_html=True)
                        
                    except Exception as e:
                        st.error(f"Error generating custom insight: {str(e)}")
                else:
                    st.info("💡 Custom insights require OpenAI API key.")

if __name__ == "__main__":
    main()
